@extends('layouts.app')
@section('content')
<div class="container mb-4">
	<div class="row">
		<div class="col-12">
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th scope="col"> </th>
							<th scope="col">Article</th>
							<th scope="col">Disponibilité</th>
							<th scope="col" class="text-center">Quantité</th>
							<th scope="col" class="text-right">Prix unitaire</th>
							<th> </th>
						</tr>
					</thead>
					<tbody>
						@foreach($orders as $order)
							<tr>
								<td><img src="http://placehold.it/50x50" /> </td>
								<td>{{$order->title}}</td>
								<td>En stock</td>
								<td class="text-center">{{$order->quantity}}</td>
								<td class="text-right">{{$order->price}} €</td>
								<td class="text-right"><button onclick="location.href='/deletePanier/{{$order->IDarticle}}'" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> </button> </td>
							</tr>
						@endforeach
						<tr>

							<td><strong>Total</strong></td>
							<td class="text-right"><strong>{{$totalPrice}} €</strong></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		<div class="col mb-2">
			<div class="row margintop">
				<div class="col-sm-12  col-md-6">
					<button onclick="location.href='/shop'" class="btn btn-block btn-light marginbot">Continuer sur la boutique</button>
				</div>
				<div class="col-sm-12 col-md-6 text-right marginbot">
					<button onclick="location.href='/confirmPanier'"class="btn btn-lg btn-block btn-success text-uppercase">Valider</button>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection