<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class profileController extends Controller
{
    function loading() {

    	$profile = DB::connection('bddnation')->table('users')->where('IDuser', Session::get('ID'))->first();
    	$profilestatus = DB::connection('bddbde')->table('status')->where('IDstatus',  Session::get('connect'))->first();
    	$profile->status = $profilestatus->status;

    	return view('profile',[
    		'profile'=>$profile,
    	]);
    }
}
