<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class profileController extends Controller
{
    function loading() {

    	$profile = DB::connection('bddnation')->table('users')->where('IDuser', Session::get('ID'))->first();
    	$profilestatus = DB::connection('bddbde')->table('status')->where('IDstatus',  Session::get('connect'))->first();
    	$profile->status = $profilestatus->status;

    	$events = DB::connection('bddbde')->table('Attendee')->where('Attendee.IDuser',Session::get('ID'))->join('events','events.IDevent','=','Attendee.IDevent')->get();
    	$ideas = DB::connection('bddbde')->table('Idea')->where('IDuser',Session::get('ID'))->get();

    	return view('profile',[
    		'profile'=>$profile,
    		'events'=>$events,
    		'ideas'=>$ideas
    	]);
    }
    function addImg () {
        request()->validate([
            'avatar' => ['required', 'image'],
        ]);

        $path = request('avatar')->store('avatars');
        return back();
    }
}
