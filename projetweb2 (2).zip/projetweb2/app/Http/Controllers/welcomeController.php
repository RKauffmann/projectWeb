<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class welcomeController extends Controller
{
    function loading() {

        $topEvents = DB::connection('bddbde')->table('events')->where('past','0')->orderBy('date','ASC')->take('3')->get();
        $topArticles = DB::connection('bddbde')->table('article')->orderBy('nbSell','DESC')->take('3')->get();
        $topIdea = DB::connection('bddbde')->table('idea')->orderBy('ts','DESC')->take('3')->get();

        return view('welcome',[
            'topEvents'=>$topEvents,
            'topArticles'=>$topArticles,
            'topIdea'=>$topIdea,
        ]);
    }
}
