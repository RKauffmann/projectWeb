<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class eventController extends Controller
{
    
	function loading(int $id) {
		$event = DB::connection('bddbde')->table('events')->where('IDevent', $id)->first();
    	$comments = DB::connection('bddbde')->table('comment')->where('IDevent', $id)->get();
    	foreach ($comments as $comment) {
    		$idcomment = DB::connection('bddnation')->table('users')->where('IDuser', $comment->IDuser)->first();
    		$comment->username = $idcomment->name;
    		$comment->userfirstname = $idcomment->first_name;
    		$comment->usercenter = $idcomment->center;
    	}

		return view('event',[
        'event'=>$event,
        'comments'=>$comments,
        'timepost' => date("Y-m-d H:m:s"),
    	]);
	}

   
}
