<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Cookie;

class logoutController extends Controller
{
    public function logout(){
    	Session::flush();
    	\Cookie::queue(\Cookie::forget('ID'));
    	\Cookie::queue(\Cookie::forget('connect'));
    	 return redirect()->route('welcome');

	}
}