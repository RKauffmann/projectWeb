<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Mail;

use App\Mail\notif;

class cartController extends Controller
{
    function loading() {
    	$panier = DB::connection('bddbde')->table('ShoppingCart')->where('IDuser',Session::get('ID'))->where('oldCommande','0')->first();
    	$totalPrice = 0;
    	if(!empty($panier)){
    		$orders = DB::connection('bddbde')->table('contains')->where('IDorder',$panier->IDorder)->join('article','article.IDarticle','=','contains.IDarticle')->get();
   		
    		foreach ($orders as $order) {
    			$totalPrice += $order->price * $order->quantity;  
       		}

	    	return view('cart',[
	    		'orders'=> $orders,
	    		'totalPrice'=>$totalPrice,
	    	]);
	    }else{
	    	return view('cart',[
	    		'orders'=> $orders = array(),
	    		'totalPrice'=>$totalPrice,
	    	]);
	    }
    }

    function deletePanier(int $id){
        DB::connection('bddbde')->table('contains')->where('IDorder',DB::connection('bddbde')->table('ShoppingCart')->where('IDuser',Session::get('ID'))->where('OldCommande','0')->first()->IDorder)->where('IDarticle', $id)->delete();

         return redirect()->route('cart');
    }

    function confirmPanier(){
        $panier = DB::connection('bddbde')->table('ShoppingCart')->where('IDuser',Session::get('ID'))->where('oldCommande','0')->first();
        if (!empty($panier)){
            Mail::to('bdeStrasbourg@viacesi.fr')->send(new notif());
            DB::connection('bddbde')->table('ShoppingCart')->where('IDuser',Session::get('ID'))->where('OldCommande','0')->update(['OldCommande'=>'1']);
        }
            return redirect()->route('shop');
    }
}
