<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class articleController extends Controller
{

    function loading(int $id){

        $article = DB::connection('bddbde')->table('article')->where('IDarticle',$id)->first();

        return view('article',[
            'article' => $article,
        ]);
    }

    function addPanier(int $id){
        $panier = DB::connection('bddbde')->table('ShoppingCart')->where('IDuser',Session::get('ID'))->where('OldCommande','0')->first();
        if(empty($panier)){
            DB::connection('bddbde')->table('ShoppingCart')->insert(['OldCommande'=>'0','IDuser'=>Session::get('ID')]);
            $panier = DB::connection('bddbde')->table('ShoppingCart')->where('IDuser',Session::get('ID'))->where('OldCommande','0')->first();
        }
        $contenuPanier = DB::connection('bddbde')->table('contains')->where('IDorder',$panier->IDorder)->where('IDarticle',$id)->first();
        if(empty($contenuPanier)){
            DB::connection('bddbde')->table('contains')->insert(['IDorder'=>$panier->IDorder, 'IDarticle'=>$id,'quantity'=>'1']);
        }else{
            DB::connection('bddbde')->table('contains')->where('IDorder',$panier->IDorder)->where('IDarticle',$id)->update(['quantity'=>$contenuPanier->quantity+1]);
        }

    return redirect()->route('cart');
    }
}
