<?php
	$ideas = DB::connection('bddbde')->table('idea')->get();
    
        $votelist =  DB::connection('bddbde')->table('voteidea')->Where('IDuser',Session::get('ID'))->get();
    	foreach ($ideas as $key => $idea) {
    		$temp = DB::connection('bddbde')->select('CALL nbvoteidealike('.$idea->IDidea.')');
    		$idea->nblike = $temp[0]->sortie;
    		$temp = DB::connection('bddbde')->select('CALL nbvoteideadislike('.$idea->IDidea.')');
    		$idea->nbdislike = $temp[0]->sortie;
            $idea->liked =  DB::connection('bddbde')->table('voteidea')->Where('IDuser',Session::get('ID'))->Where('IDidea',$idea->IDidea)->value('reaction');
    	}

   
?> 	
<?php $__currentLoopData = $ideas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
								<div class="col-sm-6">
									<div class="card">
										<div class="container-fluid">
											<div class="row">
												<div class="col-md-6">
													<div class="card-body">
														<h5 class="card-title"><?php echo e($idea->title); ?></h5>
														<p class="card-text"><?php echo e($idea->content); ?></p>
													</div>
												</div>
											</div>
										</div>
										<div class="card-footer text-muted">
												<?php if($idea->liked == 1): ?>
											<a  id="like<?php echo e($idea->IDidea); ?>" href="javascript:like(<?php echo e($idea->IDidea); ?>,<?php echo e($idea->liked); ?>)" class="btn btn-outline-primary">
											<?php elseif($idea->liked ==0): ?>
											<a  id="like<?php echo e($idea->IDidea); ?>" href="javascript:like(<?php echo e($idea->IDidea); ?>,<?php echo e($idea->liked); ?>)" class="btn btn-outline-secondary">
											<?php endif; ?>
												<i class="fas fa-thumbs-up"></i>  <span  class="likes"><?php echo e($idea->nblike); ?></span></a>
											



											<?php if($idea->liked == 0): ?>
											<a id="dislike<?php echo e($idea->IDidea); ?>" href="javascript:dislike(<?php echo e($idea->IDidea); ?>,<?php echo e($idea->liked); ?>)" class="btn btn-outline-danger">
											<?php else: ?> 
											<a id="dislike<?php echo e($idea->IDidea); ?>" href="javascript:dislike(<?php echo e($idea->IDidea); ?>,<?php echo e($idea->liked); ?>)" class="btn btn-outline-secondary">
											<?php endif; ?>
											<i class="fas fa-thumbs-down"></i>  <span class="dislikes"><?php echo e($idea->nbdislike); ?></span></a>


											 <?php if( Session::get('connect') == 3 || Cookie::get('connect') == 3): ?>
											<div class="float-right">
												<a  onclick="Valider(<?php echo e($idea->IDidea); ?>)"class="btn btn-outline-secondary">Valider</a>
											</div>
											<?php endif; ?>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>