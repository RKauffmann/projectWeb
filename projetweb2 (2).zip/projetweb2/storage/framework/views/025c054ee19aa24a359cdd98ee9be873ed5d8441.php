<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<div class="row marginbot">
		<div class="col-md-10 offset-md-1">
			<h2 class="pagetitle">Event</h2>
			<hr class="separatortitle">
		</div>
	</div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="card cardArticle">
				<div class="container-fluid">
					<div class="wrapper row">
						<div class="preview col-md-5">
							<div class="preview-pic tab-content">
								<div class="tab-pane active" id="pic-1"><img src="http://placehold.it/400x252" /></div>
							</div>
						</div>
						<div class="details col-md-7">
							<?php
								$date = explode("-", $event->date);
								$date = $date[2]."/".$date[1]."/".$date[0];
							?>
							<h3 class="product-title"><?php echo e($event->name); ?></h3>
							<p class="product-description"><?php echo e($event->description); ?></p>
							<h4>Date : <span><?php echo e($date); ?> - <?php echo e($event->punctuality); ?></span></h4>
							<h4 class="price">Prix : <span><?php if($event->price == 0): ?> <?php echo e("Gratuit"); ?> <?php else: ?> <?php echo e($event->price.'€'); ?> <?php endif; ?></span></h4>
							<p class="product-description">
								<?php echo e($event->content); ?>

							</p>
							<?php if( Session::get('connect') != null): ?>
							<div class="action">
								<button class="add-to-cart btn btn-outline-secondary" type="button">Participer</button>
							</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php if( Session::get('connect') != null): ?>
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Poster un commentaire
				</div>
				<div class="card-body">
					<form id="formcom">
						<?php echo csrf_field(); ?>
						<div class="form-group">
							<div class="form-group">
								<label for="exampleFormControlTextarea1">Votre commentaire :</label>
								<textarea class="form-control" id="newcomment" rows="3"></textarea>
							</div>
							<div class="d-flex justify-content-center">
								<button type="submit" class="btn btn-outline-secondary">Envoyer</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<?php endif; ?>
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
				</div>
				<div class="card-body">
					<ul class="list-group list-group-flush">
						<?php if(!empty($comments[0])): ?>
						<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php
							$sep = explode(" ", $comment->ts);
							$time = $sep[1];
							$date = explode("-", $sep[0]);
							$date = $date[2]."/".$date[1]."/".$date[0];
						?>
						<li class="list-group-item">
							<div class="card noborder">
								<div class="card-body">
									<h5 class="card-title marginbot"><?php echo e($comment->userfirstname); ?> <?php echo e($comment->username); ?> - <?php echo e($comment->usercenter); ?></h5>
									<h6 class="card-subtitle marginbot"><?php echo e($date); ?> <?php echo e($time); ?></h6>
									<p class="card-text"><?php echo e($comment->content); ?></p>
								</div>
							</div>
						</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<li class="list-group-item">
							<div class="card noborder">
								<div class="card-body">
									<p class="card-text">Pas de commentaire à afficher</p>
								</div>
							</div>
						</li>
						<?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
<script type="text/javascript">

	$(document).ready(()=>{
	 		$('#formcom').submit((event)=>{
	 			event.preventDefault();
	 			$.ajax({
	 						headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 				type: 'POST',
	 				url: 'http://localhost:3000/event/addcomment/',
	 				data: {
						"content" : $("#newcomment").val(),
	 					"IDuser" : <?php echo e(Session::get('ID')); ?>,
	 					"ts": "<?php echo e($timepost); ?>",
	 					"IDevent" : <?php echo e($event->IDevent); ?>,
	 				},
	 				dataType: 'json',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}
	 			});
	 		});
	 	});
</script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>