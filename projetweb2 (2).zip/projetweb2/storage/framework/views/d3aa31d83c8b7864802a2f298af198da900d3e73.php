<?php

    	$events = DB::connection('bddbde')->table('events')->orderBy('past','ASC')->orderBy('date','ASC')->get();
    	$topEvents = DB::connection('bddbde')->table('events')->where('past','0')->orderBy('date','ASC')->take('3')->get();
    	$tags = DB::connection('bddbde')->table('tag')->where('articleTag','0')->get();
        foreach ($events as $key => $event) {
            $temp = DB::connection('bddbde')->select('CALL nbvoteeventlike('.$event->IDevent.')');
            $event->nblike = $temp[0]->sortie;
            $temp = DB::connection('bddbde')->select('CALL nbvoteeventdislike('.$event->IDevent.')');
            $event->nbdislike = $temp[0]->sortie;

            $event->liked =  DB::connection('bddbde')->table('_voteevent')->Where('IDuser',Session::get('ID'))->Where('IDevent',$event->IDevent)->value('reaction');
        }
?>
<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
									$date = explode("-", $event->date);
									$showdate = $date[2]."/".$date[1]."/".$date[0];
									$date = $date[2]."-".$date[1]."-".$date[0];
								?>
								<div class="col-md-6 margintop">
									<div class="card">
										<div class="container-fluid">
											<div class="row">
												<div class="col-md-6">
													<div class="card-body">
														<h5 class="card-title"><a href="event/<?php echo e($event->IDevent); ?>"><?php echo e($event->name); ?></a></h5>
														<h6 class="card-subtitle mb-2 text-muted"><?php echo e($event->punctuality); ?> -  <?php if($event->price == 0): ?> <?php echo e("Gratuit"); ?> <?php else: ?> <?php echo e($event->price.'€'); ?> <?php endif; ?></h6>
														<p class="card-text"><?php echo e($event->description); ?></p>
													</div>
												</div>
												<div class="col-md-6 margintop marginbot d-flex justify-content-center">
													<a href="event/<?php echo e($event->IDevent); ?>"><img srcset="http://placehold.it/100" alt="responsive image" class="d-block img-fluid"></a>
												</div>
											</div>
										</div>
										<div class="card-footer text-muted">
											<?php echo e($showdate); ?>

											<?php if($event->past == 1): ?>
											<?php echo('<span class="badge badge-danger">Passé</span>') ?>
											<?php elseif($date == date('d-m-Y')): ?>
											<?php echo('<span class="badge badge-warning">Aujourd\'hui</span>') ?>
											<?php else: ?>
											<?php echo('<span class="badge badge-success">Bientôt</span>') ?>
											<?php endif; ?>
											<?php if( Session::get('connect') != null ): ?>
											<div class="float-right">
											<?php if($event->liked == 1): ?>
											<a  id="like<?php echo e($event->IDevent); ?>" href="javascript:like(<?php echo e($event->IDevent); ?>,<?php echo e($event->liked); ?>)" class="btn btn-outline-primary">
											<?php else: ?>
											<a  id="like<?php echo e($event->IDevent); ?>" href="javascript:like(<?php echo e($event->IDevent); ?>,<?php echo e($event->liked); ?>)" class="btn btn-outline-secondary">
											<?php endif; ?>
												<i class="fas fa-thumbs-up"></i>  <span  class="likes"><?php echo e($event->nblike); ?></span></a>
											
											<?php if($event->liked == 0): ?>
											<a id="dislike<?php echo e($event->IDevent); ?>" href="javascript:dislike(<?php echo e($event->IDevent); ?>,<?php echo e($event->liked); ?>)" class="btn btn-outline-danger">
											<?php else: ?> 
											<a id="dislike<?php echo e($event->IDevent); ?>" href="javascript:dislike(<?php echo e($event->IDevent); ?>,<?php echo e($event->liked); ?>)" class="btn btn-outline-secondary">
											<?php endif; ?>
											<i class="fas fa-thumbs-down"></i>  <span class="dislikes"><?php echo e($event->nbdislike); ?></span></a>
												<a href="#" class="btn btn-outline-secondary" onclick="participer(<?php echo e($event->IDevent); ?>)">Participer</a>
											</div>
											<?php endif; ?>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>