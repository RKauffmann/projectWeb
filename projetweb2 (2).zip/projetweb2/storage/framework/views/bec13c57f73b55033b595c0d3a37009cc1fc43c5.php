<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row my-2">
		<div class="col-lg-8 order-lg-2">
			<ul class="nav nav-tabs">
				<li class="nav-item">
					<a href="" data-target="#profile" data-toggle="tab" class="nav-link active"><i class="fas fa-id-card"></i> Profil</a>
				</li>
				<li class="nav-item">
					<a href="" data-target="#activity" data-toggle="tab" class="nav-link"><i class="fas fa-chart-line"></i> Activité</a>
				</li>
			</ul>
			<div class="tab-content py-4">
				<div class="tab-pane active" id="profile">
					<h5 class="mb-3"><?php echo e($profile->first_name); ?> <?php echo e($profile->name); ?></h5>
					<div class="row">
						<div class="col-md-12">
							<p>
								Rôle : <?php echo e($profile->status); ?>

							</p>
							<p>
								Adresse mail : <?php echo e($profile->email); ?>

							</p>
							<p>
								Centre : <?php echo e($profile->center); ?>

							</p>
						</div>
					</div>
				</div>
				<div class="tab-pane" id="activity">
					<div class="row">
						<div class="col-md-12">
							<h4 class="m-y-2"> idées</h4>
							<div class="alert alert-info alert-dismissable">
								<a class="panel-close close" data-dismiss="alert">×</a>
								Voici les idées que vous avez proposé
							</div>
							<?php $__currentLoopData = $ideas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php echo e($idea->title); ?><br>
								<?php echo e($idea->content); ?><br><br>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<h4 class="m-y-2">Evènements </h4>
							<div class="alert alert-info alert-dismissable">
								<a class="panel-close close" data-dismiss="alert">×</a>
								Voici les évènements auxquels vous participez
							</div>
							<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
									$date = explode("-", $event->date);
									$date = $date[2]."/".$date[1]."/".$date[0];
								?>
								<?php echo e($event->name); ?>, le <?php echo e($date); ?>	<br>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-4 order-lg-1 text-center">
			<img src="//placehold.it/150" class="mx-auto img-fluid img-circle d-block" alt="avatar">
			<form method="post" action="/avatar-modification" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="field">
                        <label class="label">Photo de profil</label>
                        <div class="control">
                            <input type="file" name="avatar" class="inout">
                        </div>
                        <?php if($errors->has('avatar')): ?>
                        <p class="help is-danger"><?php echo e($errors->first('avatar')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="field">
                        <div class="control">
                            <button class="btn btn-secondary" type="submit">Modifier ma photo de profil</button>
                        </div>
                    </div>
                </form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>