<footer class="site-footer">
	<div class="container-fluid">
		<div class="row marginbot">
			<div class="col-md-4 offset-md-4 text-center">
				Retrouvez l'activité du BDE sur
			</div>
		</div>
		<div class="row marginbot">
			<div class="col-md-4 offset-md-4 d-flex justify-content-center">
				<div class="container-fluid">
					<div class="row d-flex justify-content-center">
						<div class="col-md-1 d-flex justify-content-center">
							<a href="#"><i class="fab fa-2x fa-twitter-square"></i></a>
						</div>
						<div class="col-md-1 d-flex justify-content-center">
							<a href="#"><i class="fab fa-2x fa-linkedin"></i></a>
						</div>
						<div class="col-md-1 d-flex justify-content-center">
							<a href="#"><i class="fab fa-2x fa-youtube-square"></i></a>
						</div>
						<div class="col-md-1 d-flex justify-content-center">
							<a href="#"><i class="fab fa-2x fa-instagram"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row d-flex justify-content-center marginbot">
			<div class="col-md-4">
				<div class="container-fluid">
					<div class="row d-flex justify-content-center">
						<div class="col-md-auto d-flex justify-content-center">
							<a href="#">Politique de confidentialité</a>
						</div>
						<div class="col-md-auto d-flex justify-content-center">
							<a href="#">Mentions légales</a>
						</div>
						<div class="col-md-auto d-flex justify-content-center">
							<a href="#">Crédits</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row d-flex justify-content-center">
			<div class="col-md-6">
				<div class="container-fluid">
					<div class="row d-flex justify-content-center">
						<div class="col-md-12">
							<p class="text-center">@BDECESI 2019</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>