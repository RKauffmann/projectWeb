<?php

namespace App\Http\Controllers;

use Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
class eventsController extends Controller
{
    function loading() {

    	$events = DB::connection('bddbde')->table('events')->orderBy('past','ASC')->orderBy('date','ASC')->get();
    	$topEvents = DB::connection('bddbde')->table('events')->where('past','0')->orderBy('date','ASC')->take('3')->get();
    	$tags = DB::connection('bddbde')->table('tag')->where('articleTag','0')->get();
        foreach ($events as $key => $event) {
            $temp = DB::connection('bddbde')->select('CALL nbvoteeventlike('.$event->IDevent.')');
            $event->nblike = $temp[0]->sortie;
            $temp = DB::connection('bddbde')->select('CALL nbvoteeventdislike('.$event->IDevent.')');
            $event->nbdislike = $temp[0]->sortie;

            $event->liked =  DB::connection('bddbde')->table('_voteevent')->Where('IDuser',Session::get('ID'))->Where('IDevent',$event->IDevent)->value('reaction');
        }
        return view('events',[
            'events'=>$events,
            'tags'=>$tags,
            'topEvents'=>$topEvents,
            'time' => date("Y-m-d H:i:s"),
        ]);
    }
     function filtreEvent(Request $request){
        
        $topEvents = DB::connection('bddbde')->table('events')->where('past','0')->orderBy('date','ASC')->take('3')->get();
        $tags = DB::connection('bddbde')->table('tag')->where('articleTag','0')->get();

        $events = DB::connection('bddbde')->table('events')->join('describevents', 'events.IDevent' ,'=','describevents.IDevent')->where('describevents.IDtag',Request::get('filtre'))->get();
        foreach ($events as $key => $event) {
              $temp = DB::connection('bddbde')->select('CALL nbvoteeventlike('.$event->IDevent.')');
              $event->nblike = $temp[0]->sortie;
              $temp = DB::connection('bddbde')->select('CALL nbvoteeventdislike('.$event->IDevent.')');
              $event->nbdislike = $temp[0]->sortie;
              $event->liked =  DB::connection('bddbde')->table('_voteevent')->Where('IDuser',Session::get('ID'))->Where('IDevent',$event->IDevent)->value('reaction');
          }
        return view('events',[
            'events'=>$events,
            'tags'=>$tags,
            'topEvents'=>$topEvents,
            'time' => date("Y-m-d H:i:s"),
        ]);
    }
}
