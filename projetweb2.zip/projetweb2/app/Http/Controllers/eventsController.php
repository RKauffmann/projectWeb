<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class eventsController extends Controller
{
    function loading() {

    	$events = DB::connection('bddbde')->table('events')->orderBy('past','ASC')->orderBy('date','ASC')->get();
    	$topEvents = DB::connection('bddbde')->table('events')->where('past','0')->orderBy('date','ASC')->take('3')->get();
    	$tags = DB::connection('bddbde')->table('tag')->where('articleTag','0')->get();
        return view('events',[
            'events'=>$events,
            'tags'=>$tags,
            'topEvents'=>$topEvents,
            'time' => date("Y-m-d H:i:s"),
        ]);
    }
}
