<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;

use App\Mail\notifSignalementEvenement;

class eventsController extends Controller
{
    function loading() {

    	$events = DB::connection('bddbde')->table('events')->orderBy('past','ASC')->orderBy('date','ASC')->get();
    	$topEvents = DB::connection('bddbde')->table('events')->orderBy('date','ASC')->take('3')->get();
    	$tags = DB::connection('bddbde')->table('tag')->where('articleTag','0')->get();
        foreach ($events as $key => $event) {
            $temp = DB::connection('bddbde')->select('CALL nbvoteeventlike('.$event->IDevent.')');
            $event->nblike = $temp[0]->sortie;
            $temp = DB::connection('bddbde')->select('CALL nbvoteeventdislike('.$event->IDevent.')');
            $event->nbdislike = $temp[0]->sortie;

            $event->liked =  DB::connection('bddbde')->table('_voteevent')->Where('IDuser',Session::get('ID'))->Where('IDevent',$event->IDevent)->value('reaction');
        }
        return view('events',[
            'events'=>$events,
            'tags'=>$tags,
            'topEvents'=>$topEvents,
            'time' => date("Y-m-d H:i:s"),
        ]);
    }
     function filtreEvent(Request $request){
        
        $topEvents = DB::connection('bddbde')->table('events')->where('past','0')->orderBy('date','ASC')->take('3')->get();
        $tags = DB::connection('bddbde')->table('tag')->where('articleTag','0')->get();

        $events = DB::connection('bddbde')->table('events')->join('describevents', 'events.IDevent' ,'=','describevents.IDevent')->where('describevents.IDtag',Request::get('filtre'))->get();
        foreach ($events as $key => $event) {
              $temp = DB::connection('bddbde')->select('CALL nbvoteeventlike('.$event->IDevent.')');
              $event->nblike = $temp[0]->sortie;
              $temp = DB::connection('bddbde')->select('CALL nbvoteeventdislike('.$event->IDevent.')');
              $event->nbdislike = $temp[0]->sortie;
              $event->liked =  DB::connection('bddbde')->table('_voteevent')->Where('IDuser',Session::get('ID'))->Where('IDevent',$event->IDevent)->value('reaction');
          }
        return view('events',[
            'events'=>$events,
            'tags'=>$tags,
            'topEvents'=>$topEvents,
            'time' => date("Y-m-d H:i:s"),
        ]);
    }
     function uploadimg(request $request){

  request()->validate([
             'eventname' => ['required','max:25','string'],
             'eventshortdesc' => ['required','max:250','string'],
             'eventimg' => ['required', 'image'],
             'eventdate' => ['required'],
             'eventlongdesc' => ['required','string','max:1500'],
             'eventprice' => ['required','numeric','max:999'],
          'eventpunctuality' => ['required','string','max:25']
        ]);
    $path = request()->file('eventimg')->store('events','public');
    DB::connection('bddbde')->table('events')->insert(['name' => $request->input('eventname'),'description'=> $request->input('eventshortdesc'),'date' => $request('eventdate'),'thumbnail' => $path,'content' => $request->input('eventlongdesc'),'past' => '0','price'=> $request->input('eventprice'),'IDuser'=> Session::get('ID'),'punctuality'=>$request->input('eventpunctuality')]);
    
        return back();
    }

    function sendMailEvents($id){

      $bdes = DB::connection('bddbde')->table('users')->Where('IDstatus','3')->get();
      foreach($bdes as $bde){
        $mail = new notifSignalementEvenement($id);
        $users = DB::connection('bddnation')->table('users')->where('IDuser', $bde->IDuser)->first()->email;
        Mail::to($users)->send($mail);
      }
      return back();
    }

}
