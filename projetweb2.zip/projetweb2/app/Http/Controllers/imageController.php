<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class imageController extends Controller
{
    function loading(int $id){

    	$image = DB::connection('bddbde')->table('image')->where('IDimg', $id)->first();
    	$comments = DB::connection('bddbde')->table('comment')->where('IDcomment_image', $id)->get();
    	foreach ($comments as $comment) {
    		$idcomment = DB::connection('bddnation')->table('users')->where('IDuser', $comment->IDuser)->first();
    		$comment->username = $idcomment->name;
    		$comment->userfirstname = $idcomment->first_name;
    		$comment->usercenter = $idcomment->center;
    	}

            $temp = DB::connection('bddbde')->select('CALL nbvoteimglike('.$id.')');
            $image->nblike = $temp[0]->sortie;
            $temp = DB::connection('bddbde')->select('CALL nbvoteimgdislike('.$id.')');
            $image->nbdislike = $temp[0]->sortie;
            $image->liked = DB::connection('bddbde')->table('voteimg')->Where('IDuser',Session::get('ID'))->Where('IDVoteimg',$id)->value('reaction');

    	$event = DB::connection('bddbde')->table('events')->where('IDevent', $image->IDevent)->first();
    	$image->event = $event->name;

    	return view('image',[
        'image'=>$image,
        'comments'=>$comments,
        'timepost' => date("Y-m-d H:m:s"),
    	]);
    }
	
}
