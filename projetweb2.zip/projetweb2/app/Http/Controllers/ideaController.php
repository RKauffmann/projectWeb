<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
class ideaController extends Controller
{
    public function loading(){

    	$idea = DB::connection('bddbde')->table('idea')->get();
    
        $votelist =  DB::connection('bddbde')->table('voteidea')->Where('IDuser',Session::get('ID'))->get();
    	foreach ($idea as $key => $value) {
    		$temp = DB::connection('bddbde')->select('CALL nbvoteidealike('.$value->IDidea.')');
    		$value->nblike = $temp[0]->sortie;
    		$temp = DB::connection('bddbde')->select('CALL nbvoteideadislike('.$value->IDidea.')');
    		$value->nbdislike = $temp[0]->sortie;
            $value->liked = DB::connection('bddbde')->table('voteidea')->Where('IDuser',Session::get('ID'))->Where('IDidea',$value->IDidea)->value('reaction');
    	}

    	$tags =  DB::connection('bddbde')->table('tag')->get();
    	return view('ideabox',[
    							'ideas' => $idea,
    							'tags' => $tags,
                                'time' => date("Y-m-d H:i:s"),
                                'votelist' => $votelist
    				]);
}

}
