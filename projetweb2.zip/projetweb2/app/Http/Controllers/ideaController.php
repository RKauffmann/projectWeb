<?php

namespace App\Http\Controllers;
use Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Mail;

use App\Mail\notifSignalementIdee;
use App\Mail\notifValidationIdee;
class ideaController extends Controller
{
    public function loading(){

    	$ideas = DB::connection('bddbde')->table('idea')->get();
    
        $votelist =  DB::connection('bddbde')->table('voteidea')->Where('IDuser',Session::get('ID'))->get();
    	foreach ($ideas as $key => $idea) {
    		$temp = DB::connection('bddbde')->select('CALL nbvoteidealike('.$idea->IDidea.')');
    		$idea->nblike = $temp[0]->sortie;
    		$temp = DB::connection('bddbde')->select('CALL nbvoteideadislike('.$idea->IDidea.')');
    		$idea->nbdislike = $temp[0]->sortie;
            $idea->liked =  DB::connection('bddbde')->table('voteidea')->Where('IDuser',Session::get('ID'))->Where('IDidea',$idea->IDidea)->value('reaction');
    	}

    	$tags =  DB::connection('bddbde')->table('tag')->get();
    	return view('ideabox',[
    							'ideas' => $ideas,
    							'tags' => $tags,
                                'time' => date("Y-m-d H:m:s"),
                                'votelist' => $votelist
    				]);
}
function filtreIdea(Request $request){
        
        $ideas = DB::connection('bddbde')->table('idea')->join('describidea','idea.IDidea','=','describidea.IDidea')->where('describidea.IDtag',Request::get('filtre'))->get();
    
        $votelist =  DB::connection('bddbde')->table('voteidea')->Where('IDuser',Session::get('ID'))->get();
        foreach ($ideas as $key => $idea) {
            $temp = DB::connection('bddbde')->select('CALL nbvoteidealike('.$idea->IDidea.')');
            $idea->nblike = $temp[0]->sortie;
            $temp = DB::connection('bddbde')->select('CALL nbvoteideadislike('.$idea->IDidea.')');
            $idea->nbdislike = $temp[0]->sortie;
            $idea->liked = DB::connection('bddbde')->table('voteidea')->Where('IDuser',Session::get('ID'))->Where('IDidea',$idea->IDidea)->value('reaction');
        }

        $tags =  DB::connection('bddbde')->table('tag')->get();


        return view('ideabox',[
            'ideas' => $ideas,
            'tags' => $tags,
            'time' => date("Y-m-d H:i:s"),
            'votelist' => $votelist
        ]);
    }

    function sendMail($id){

            $bdes = DB::connection('bddbde')->table('users')->Where('IDstatus','3')->get();
            foreach($bdes as $bde){
                $mail = new notifSignalementIdee($id);
                $users = DB::connection('bddnation')->table('users')->where('IDuser', $bde->IDuser)->first()->email;
                Mail::to($users)->send($mail);
            }
            return back();
        }



        function sendMailValidation($id){

                $creator = DB::connection('bddbde')->table('idea')->where('IDidea',$id)->first()->IDuser;
                $user = DB::connection('bddnation')->table('users')->where('IDuser',$creator)->first()->email;
                $mail = new notifValidationIdee($id);
                
                Mail::to($user)->send($mail);
            
            return back();
        }
        function valider($IDidea){
            DB::connection('bddbde')->table('voteidea')->where('IDidea',$IDidea)->delete();
            DB::connection('bddbde')->table('idea')->where('IDidea',$IDidea)->delete();
            return back();
        }
}
