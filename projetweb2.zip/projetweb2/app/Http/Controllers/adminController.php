<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class adminController extends Controller
{
    function loading() {

    	$profiles = DB::connection('bddnation')->table('users')->get();
    	foreach ($profiles as $profile) {
    		$status = DB::connection('bddbde')->table('users')->where('IDuser', $profile->IDuser)->first();
    		$profilestatus = DB::connection('bddbde')->table('status')->where('IDstatus', $status->IDstatus)->first();
    		$profile->status = $profilestatus->status;
    	}
    	$events = DB::connection('bddbde')->table('events')->get();
    
    	return view('admin',[
    		'profiles'=>$profiles,
    		'events'=>$events,
    	]);
    }
    
}
