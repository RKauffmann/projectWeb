<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class profileController extends Controller
{
    function loading(int $id) {

    	$profile = DB::connection('bddnation')->table('users')->where('IDuser', $id)->first();
    	$status = DB::connection('bddbde')->table('users')->where('IDuser', $id)->first();
    	$profilestatus = DB::connection('bddbde')->table('status')->where('IDstatus', $status->IDstatus)->first();
    	$profile->status = $profilestatus->status;

    	return view('profile',[
    		'profile'=>$profile,
    	]);
    }
}
