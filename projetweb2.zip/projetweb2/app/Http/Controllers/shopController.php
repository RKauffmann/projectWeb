<?php

namespace App\Http\Controllers;

use Request;
use Illuminate\Support\Facades\DB;

class shopController extends Controller
{
    function loading(){

    	$articles = DB::connection('bddbde')->table('article')->get();
    	$topArticles = DB::connection('bddbde')->table('article')->orderBy('nbSell','DESC')->take('3')->get();
    	$tags = DB::connection('bddbde')->table('tag')->where('articleTag','1')->get();
        $tagsArticle = DB::connection('bddbde')->table('describarticle')->get();

        foreach($articles as $article){
            $i=0;
            foreach($tagsArticle as $tagArticle){
                if($tagArticle->IDarticle==$article->IDarticle){
                    $article->tag[$i]=$tagArticle->IDtag;
                    $i++;
                }
            }
        }


    	return view('shop',[
    		'articles'=>$articles,
    		'topArticles'=>$topArticles,
    		'tags'=>$tags,
    	]);
    }

    function filtreShop(Request $request){

        $topArticles = DB::connection('bddbde')->table('article')->orderBy('nbSell','DESC')->take('3')->get();
        $tags = DB::connection('bddbde')->table('tag')->where('articleTag','1')->get();

        $articles = DB::connection('bddbde')->table('article')->join('describarticle', 'article.IDarticle' ,'=','describarticle.IDarticle')->where('describarticle.IDtag',Request::get('filtre'))->get();

        return view('shop',[
            'articles'=>$articles,
            'topArticles'=>$topArticles,
            'tags'=>$tags,
        ]);
    }
}
