<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Session;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function login(Request $request){

     
     $url = 'http://localhost:3000/'. $request->input('email').'/';
     $opts=array(
        "http"=>array(
        'method'=>"GET"
    ),
); 
     $response = file_get_contents($url,false,stream_context_create($opts));
     $jsontab = json_decode($response);
      
     if(!empty($jsontab[0]->password)){
        
          if(Hash::check($request->input('password'),$jsontab[0]->password))
                   {
                   $Statment = DB::connection('bddbde')->table('users')->Where('IDuser',$jsontab[0]->IDuser)->first();
                             if(!empty($Statment)){ 
                                if(!is_null($request->remember)){
                                       Cookie::queue('connect',$Statment->IDstatus,60*60*24*365);
                                       Cookie::queue('ID',$jsontab[0]->IDuser,60*60*24*365);
                                            } 

                                        Session::put('connect',$Statment->IDstatus);
                                        Session::put('ID',$jsontab[0]->IDuser);
                                //   echo Session::get('connect');
                                        return view('welcome');  
                            }
                     }

              }
           
         }
}
      
