<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Cookie;
class logoutController extends Controller
{
    public function logout(){
    	session()->forget('connect');
    	session()->forget('ID');
    	\Cookie::queue(\Cookie::forget('ID'));
    	\Cookie::queue(\Cookie::forget('connect'));
    	return view('welcome');

	}
}