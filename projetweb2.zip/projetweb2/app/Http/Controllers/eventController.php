<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;

use App\Mail\notifSignalementEvenementImage;
use App\Mail\notifSignalementCommentaire;

class eventController extends Controller
{
    
	function loading(int $id) {
		$event = DB::connection('bddbde')->table('events')->where('IDevent', $id)->first();
    $event->attendee = DB::connection('bddbde')->table('attendee')->Where('IDevent',$event->IDevent)->Where('IDuser',Session::get('ID'))->exists();
        $images = DB::connection('bddbde')->table('image')->where('IDevent', $id)->get();
    	$comments = DB::connection('bddbde')->table('comment')->where('IDevent', $id)->get();
    	foreach ($comments as $comment) {
    		$idcomment = DB::connection('bddnation')->table('users')->where('IDuser', $comment->IDuser)->first();
    		$comment->username = $idcomment->name;
    		$comment->userfirstname = $idcomment->first_name;
    		$comment->usercenter = $idcomment->center;
    	}

		return view('event',[
        'event'=>$event,
        'comments'=>$comments,
         'images'=>$images,
          'timepost' => date("Y-m-d H:m:s"),
    	]);
	}

    function sendMailEventImg($id){

           $bdes = DB::connection('bddbde')->table('users')->Where('IDstatus','3')->get();
          foreach($bdes as $bde){
               $mail = new notifSignalementEvenementImage($id);
               $users = DB::connection('bddnation')->table('users')->where('IDuser', $bde->IDuser)->first()->email;
              Mail::to($users)->send($mail);
           }
          return back();
        }
   
    function sendMailComment($id){

           $bdes = DB::connection('bddbde')->table('users')->Where('IDstatus','3')->get();
          foreach($bdes as $bde){
               $mail = new notifSignalementCommentaire($id);
               $users = DB::connection('bddnation')->table('users')->where('IDuser', $bde->IDuser)->first()->email;
              Mail::to($users)->send($mail);
           }
          return back();
        }


        function addImg ($IDevent) {
        request()->validate([
            'eventImg' => ['required', 'image'],
        ]);
        $path = request('eventImg')->store('events','public');
        DB::connection('bddbde')->table('image')->insert(['content'=> $path,'ts'=> date("Y-m-d H-m-s"),"IDuser"=> Session::get('ID'),"IDevent"=> $IDevent]);
        return back();
    }
}
