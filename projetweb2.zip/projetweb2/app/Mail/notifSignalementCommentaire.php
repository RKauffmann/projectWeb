<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class notifSignalementCommentaire extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($id)
    {
        $this->id=$id;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {

        $user = DB::connection('bddnation')->table('users')->where('IDuser',Session::get('ID'))->first();
        $comments = DB::connection('bddbde')->table('comment')->where('IDcomment', $this->id)->get();

        foreach ($comments as $comment) {
            $idcomment = DB::connection('bddnation')->table('users')->where('IDuser', $comment->IDuser)->first();
            $comment->username = $idcomment->name;
            $comment->userfirstname = $idcomment->first_name;
            $comment->usercenter = $idcomment->center;
        }

        
        return $this->from('bde-website@viacesi.fr')->view('mails.notifSignalementCommentaire',[
            'user'=>$user,
            'comment'=>$comment
        ]);
    }
}
