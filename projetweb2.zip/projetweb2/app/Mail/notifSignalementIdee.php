<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;


use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class notifSignalementIdee extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($id)
    {
        $this->id=$id;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $user = DB::connection('bddnation')->table('users')->where('IDuser',Session::get('ID'))->first();

        $ideas = DB::connection('bddbde')->table('idea')->where('IDidea', $this->id)->get();

        foreach ($ideas as $idea) {
            $ididea = DB::connection('bddnation')->table('users')->where('IDuser', $idea->IDuser)->first();
            $idea->username = $ididea->name;
            $idea->userfirstname = $ididea->first_name;
            $idea->usercenter = $ididea->center;
        }

        
        return $this->from('bde-website@viacesi.fr')->view('mails.notifSignalementIdee',[
            'user'=>$user,
            'idea'=>$idea
        ]);
    }
    }