<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class notifAjouterPanier extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {

        $user = DB::connection('bddnation')->table('users')->where('IDuser',Session::get('ID'))->first();
  
        $orders = DB::connection('bddbde')->table('contains')->where('IDorder',DB::connection('bddbde')->table('ShoppingCart')->where('IDuser',Session::get('ID'))->where('oldCommande','0')->first()->IDorder)->join('article','article.IDarticle','=','contains.IDarticle')->get();
        
        $totalPrice = 0;
        foreach ($orders as $order) {
            $totalPrice += $order->price * $order->quantity;  
        }

        return $this->from('bde-website@viacesi.fr')->view('mails.notifAjouterPanier',[
            'user'=>$user,
            'orders'=>$orders,
            'totalPrice'=>$totalPrice
        ]);
    }
}
