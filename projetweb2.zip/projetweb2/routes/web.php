<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::get('idea','ideaController@loading')->name('idea');

Route::get('admin',function(){
	return view('admin');
})->name('admin');

Route::get('legalnotice',function(){
	return view('legalnotice');
})->name('legalnotice');

Route::get('logout','Auth\logoutController@logout')->name('logout');

Route::get('profile/{id}',['uses'=>'profileController@loading']);

Route::post('register', 'Auth\RegisterController@createaccount')->name('register');
Route::get('register', function(){
	return view('auth/register');
})->name('register');

Route::post('login', 'Auth\LoginController@login')->name('login');
Route::get('login',function(){
	return view('auth/login');
})->name('login');

Route::get('events', 'eventsController@loading')->name('events');

Route::get('event/{id}',['uses'=>'eventController@loading']);

Route::get('cart', 'cartController@loading')->name('cart');
Route::get('article/{id}','articleController@loading');

Route::get('shop', 'shopController@loading')->name('shop');
Route::post('filtreShop','shopController@filtreShop')->name('filtreShop');
Route::get('addPanier/{id}','articleController@addPanier');