<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!

*/

Route::get('/','welcomeController@loading')->name('welcome');

Route::get('legalnotice',function(){
	return view('legalnotice');
})->name('legalnotice');

Route::get('idea','ideaController@loading')->name('idea');
Route::post('filtreIdea','IdeaController@filtreIdea')->name('filtreIdea');
Route::get('ideavalid/{IDidea}','IdeaController@valider');

Route::get('refreshidea',function(){
	return view('refreshidea');
})->name('refreshidea');

Route::get('admin', 'adminController@loading')->name('admin');


Route::get('profil','profileController@loading')->name('profil');
Route::post('avatar-modification','profileController@addImg');
Route::post('dlallimg','profileController@dlallimg');

Route::post('register', 'Auth\RegisterController@createaccount')->name('register');
Route::get('register', function(){
	return view('auth/register');
})->name('register');
Route::get('logout','Auth\logoutController@logout')->name('logout');
Route::post('login', 'Auth\LoginController@login')->name('login');
Route::get('login',function(){
	return view('auth/login');
})->name('login');

Route::get('events', 'eventsController@loading')->name('events');
Route::get('event/{id}','eventController@loading');
Route::post('filtreEvent','EventsController@filtreEvent')->name('filtreEvent');
Route::post('events','eventsController@uploadimg')->name('events');
Route::get('event/image/{id}', 'imageController@loading');
Route::post('event/addimg/{id}','eventController@addImg');
Route::get('refreshevent',function(){
	return view('refreshevent');
})->name('refreshevent');

Route::get('cart', 'cartController@loading')->name('cart');
Route::get('article/{id}','articleController@loading');
Route::get('shop', 'shopController@loading')->name('shop');
Route::post('filtreShop','shopController@filtreShop')->name('filtreShop');
Route::get('addPanier/{id}','articleController@addPanier');

Route::get('deletePanier/{id}','cartController@deletePanier');

Route::get('confirmPanier', 'cartController@confirmPanier');
Route::post('newArticle', 'shopController@newArticle')->name('newArticle');

Route::get('sendMailEvents/{id}', 'eventsController@sendMailEvents')->name('sendMailEvents');
Route::get('sendMailEventImg/{id}', 'eventController@sendMailEventImg')->name('sendMailEventImg');
Route::get('sendMail/{id}', 'ideaController@sendMail')->name('sendMail');
Route::get('sendMailComment/{id}', 'eventController@sendMailComment')->name('sendMailComment');
Route::get('sendMailValidation/{id}', 'ideaController@sendMailValidation')->name('sendMailValidation');