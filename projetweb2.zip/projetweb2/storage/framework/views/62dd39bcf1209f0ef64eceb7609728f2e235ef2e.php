<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row marginbot">
        <div class="col-md-10 offset-md-1">
            <h2 class="pagetitle">Page d'administration</h2>
            <hr class="separatortitle">
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-10 order-md-2">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a href="" data-target="#profile" data-toggle="tab" class="nav-link active"><i class="fas fa-users"></i> Utilisateurs</a>
                </li>
                <li class="nav-item">
                    <a href="" data-target="#activity" data-toggle="tab" class="nav-link"><i class="fas fa-calendar-week"></i> Evènements</a>
                </li>
                <li class="nav-item">
                    <a href="" data-target="#settings" data-toggle="tab" class="nav-link"><i class="fas fa-shopping-basket"></i> Boutique</a>
                </li>
            </ul>
            <div class="tab-content py-4">
                <div class="tab-pane active" id="profile">
                    <h5 class="mb-3"></h5>
                    <div class="row">
                        <div class="col-md-12">
                            <body>
                                <table id="usertab" class="display" style="width: 100%">
                                    <thead>
                                        <tr><th>Nom</th><th>Prénom</th><th>Centre</th><th>Rôle</th><th>Adresse mail</th></tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr><td><?php echo e($profile->name); ?></td><td><?php echo e($profile->first_name); ?></td><td><?php echo e($profile->center); ?></td><td><?php echo e($profile->status); ?></td><td><?php echo e($profile->email); ?></td></tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </body>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="activity">
                    <div class="row">
                        <div class="col-md-12">
                            <body>
                                <table id="eventtab" class="display" style="width: 100%">
                                    <thead>
                                        <tr><th>Nom</th><th>Description courte</th><th>Date</th><th>Prix</th><th>Statut</th><th>Proposé par</th></tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr><td><?php echo e($event->name); ?></td><td><?php echo e($event->description); ?></td><td><?php echo e($event->date); ?></td><td><?php echo e($event->price); ?></td><td><?php echo e($event->past); ?></td><td><?php echo e($event->IDuser); ?></td></tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </body>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>