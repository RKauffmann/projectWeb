<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="col-md-10 offset-md-1">
        <div class="row marginbot">
            <h2 class="pagetitle">Accueil</h2>
            <hr class="separatortitle">
        </div>
        <br>
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <h1>Notre Campus</h1>
                <div class="row">
                    <div class="col-md-8">
                        <strong>Le campus CESI Strasbourg est l’un des 4 campus de la direction régionale Est de CESI.</strong>
                        <p> Implanté en Alsace depuis 1971 à la demande des entreprises locales, le campus accueille chaque année près de 900 élèves au Parc des Tanneries de Lingolsheim.</p>
                        <p>Au cœur d’une région dynamique, aux frontières de 4 pays européens (Allemagne, Suisse, Luxembourg et Belgique), Strasbourg se démarque par la richesse de ses échanges internationaux et son patrimoine mondialement connu et apprécié.</p>
                        <p>Avec pour finalité le développement des compétences au sein des entreprises ainsi que la professionnalisation d’étudiants, d’alternants et de salariés sur des niveaux de technicien supérieur à cadre et ingénieurs, <span class="stabilo">Campus CESI Strasbourg</span> développe une large offre de parcours d’excellence dans les domaines de l’Informatique, des Ressources Humaines, de la Qualité Sécurité Environnement, de la Performance industrielle, du BTP et du Management.
                    Grâce aux salles BIM (maquette numérique), au fablab et autres dispositifs de pédagogie active, nos élèves peuvent acquérir de nouvelles compétences, expérimenter en groupe, développer leur professionnalisme et s’assurer un avenir professionnel dès la validation de leur diplôme.</p>
                    <address>Adresse : Parc Club des Tanneries, 2 Allée des Foulons, 67380 Strasbourg, Lingolsheim, Téléphone : <span class="stabilo">03 88 10 35 60</span></address>
                </div>
                <div class="row">
                    <div id="carousel" class="carousel slide carousel-fade" data-ride="carousel" data-interval="6000">
                        <ol class="carousel-indicators">
                            <li data-target="#carousel" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel" data-slide-to="1"></li>
                            <li data-target="#carousel" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <a href="#">
                                    <img src="http://placehold.it/400x400" alt="responsive image" class="d-block img-fluid">
                                    <div class="carousel-caption">
                                        <div>
                                            <h2>Test</h2>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- /.carousel-item -->
                            <div class="carousel-item">
                                <a href="#">
                                    <img src="http://placehold.it/400x400" alt="responsive image" class="d-block img-fluid">
                                    <div class="carousel-caption justify-content-center align-items-center">
                                        <div>
                                            <h2>Test</h2>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- /.carousel-item -->
                            <div class="carousel-item">
                                <a href="#">
                                    <img src="http://placehold.it/400x400" alt="responsive image" class="d-block img-fluid">
                                    
                                    <div class="carousel-caption justify-content-center align-items-center">
                                        <div>
                                            <h2>Test</h2>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- /.carousel-item -->
                        </div>
                        <!-- /.carousel-inner -->
                        <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="row margin">
        <div class="col-md-10 offset-md-1">
            <h1>Les prochains événements</h1>
            <div id="carousel1" class="carousel slide carousel-fade" data-ride="carousel" data-interval="6000">
                <ol class="carousel-indicators">
                    <li data-target="#carousel1" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel1" data-slide-to="1"></li>
                    <li data-target="#carousel1" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner" role="listbox">
                    <div class="carousel-item active">
                        <a href="#">
                            <img src="/storage/<?php echo e($topEvents[0]->thumbnail); ?>" alt="responsive image" class="d-block img-fluid">
                            <div class="carousel-caption">
                                <div>
                                    <h2><?php echo e($topEvents[0]->name); ?></h2>
                                    <p><?php echo e($topEvents[0]-> description); ?>.</p>
                                    <span class="btn btn-sm btn-outline-secondary">Voir</span>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- /.carousel-item -->
                    <div class="carousel-item">
                        <a href="#">
                            <img src="/storage/<?php echo e($topEvents[1]->thumbnail); ?>" alt="responsive image" class="d-block img-fluid">
                            <div class="carousel-caption justify-content-center align-items-center">
                                <div>
                                    <h2><?php echo e($topEvents[1]->name); ?></h2>
                                    <p><?php echo e($topEvents[1]-> description); ?>.</p>
                                    <span class="btn btn-sm btn-outline-secondary">Voir</span>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- /.carousel-item -->
                    <div class="carousel-item">
                        <a href="#">
                            <img src="/storage/<?php echo e($topEvents[0]->thumbnail); ?>" alt="responsive image" class="d-block img-fluid">
                            
                            <div class="carousel-caption justify-content-center align-items-center">
                                <div>
                                    <h2><?php echo e($topEvents[2]->name); ?></h2>
                                    <p><?php echo e($topEvents[2]-> description); ?>.</p>
                                    <span class="btn btn-sm btn-outline-secondary">Voir</span>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- /.carousel-item -->
                </div>
                <!-- /.carousel-inner -->
                <a class="carousel-control-prev" href="#carousel1" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carousel1" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
    <div class="row margin">
        <div class="col-md-10 offset-md-1">
            <h1>La boutique</h1>
        </div>
        <?php $__currentLoopData = $topArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 offset-md-1">
            <div class="card h-100">
                <a href="#"><img class="card-img-top" src="/storage/<?php echo e($article->thumbnail); ?>" alt=""></a>
                <div class="card-body">
                    <h4 class="card-title">
                    <a href="#"><?php echo e($article->title); ?></a>
                    </h4>
                    <h5><?php echo e($article->price); ?>€</h5>
                    <p class="card-text"><?php echo e($article->description); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
        <div class="row margin">
            <div class="col-md-10 offset-md-1">
                <h1>Les dernières idées</h1>
                                <div>
                                <img srcset="<?php echo e(asset('img/welcompage.jpg')); ?>" alt="responsive image" class="d-block img-fluid">
                                <button onclick="location.href='/idea'">donner vos idées</button>
                                </div>
                               
            </div>
        </div>
    </div>
</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>