Félicitation <?php echo e($user->name); ?> <?php echo e($user->first_name); ?> !
<br>
<p>Ton idée <strong><?php echo e($idea->title); ?></strong> a été accepté .</p>