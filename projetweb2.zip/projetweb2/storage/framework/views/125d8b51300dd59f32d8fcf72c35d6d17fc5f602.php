<?php $__env->startSection('content'); ?>
<?php
$token = Session::get('token');
?>

<div class="container-fluid">
	<div class="row marginbot">
		<div class="col-md-10 offset-md-1">
			<h2 class="pagetitle">Image - <?php echo e($image->event); ?></h2>
			<hr class="separatortitle">
		</div>
	</div>
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card w-100">
				<div class="card-body">
					<div class="container-fluid">
						<div class="row d-flex justify-content-center marginbot">
							<img src="/storage/<?php echo e($image->content); ?>" alt="Card image cap">
						</div>
						<div class="row d-flex justify-content-center">
							<div class="float-right">
								<?php if($image->liked == 1): ?>
									<a  id="like<?php echo e($image->IDimg); ?>" href="javascript:like(<?php echo e($image->IDimg); ?>,<?php echo e($image->liked); ?>)" class="btn btn-outline-primary">
								<?php else: ?>
									<a  id="like<?php echo e($image->IDimg); ?>" href="javascript:like(<?php echo e($image->IDimg); ?>,<?php echo e($image->liked); ?>)" class="btn btn-outline-secondary">
								<?php endif; ?>
									<i class="fas fa-thumbs-up"></i>  <span  class="likes"><?php echo e($image->nblike); ?></span></a>
								<?php if($image->liked == 2): ?>
									<a id="dislike<?php echo e($image->IDimg); ?>" href="javascript:dislike(<?php echo e($image->IDimg); ?>,<?php echo e($image->liked); ?>)" class="btn btn-outline-danger">
								<?php else: ?>
									<a id="dislike<?php echo e($image->IDimg); ?>" href="javascript:dislike(<?php echo e($image->IDimg); ?>,<?php echo e($image->liked); ?>)" class="btn btn-outline-secondary">
								<?php endif; ?>
								<i class="fas fa-thumbs-down"></i>  <span class="dislikes"><?php echo e($image->nbdislike); ?></span></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php if( Session::get('connect') != null): ?>
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Poster un commentaire
				</div>
				<div class="card-body">
					<form id='postCommentImg'>
						<div class="form-group">
							<div class="form-group">
								<label for="exampleFormControlTextarea1">Votre commentaire :</label>
								<textarea class="form-control" id="newcomment" rows="3"></textarea>
							</div>
							<div class="d-flex justify-content-center">
								<button type="submit" class="btn btn-outline-secondary">Envoyer</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<?php endif; ?>
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Commentaires
				</div>
				<div class="card-body">
					<ul class="list-group list-group-flush">
						<?php if(!empty($comments[0])): ?>
						<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php
							$sep = explode(" ", $comment->ts);
							$time = $sep[1];
							$date = explode("-", $sep[0]);
							$date = $date[2]."/".$date[1]."/".$date[0];
						?>
						<li class="list-group-item">
							<div class="card noborder">
								<div class="card-body">
									<h5 class="card-title marginbot"><?php echo e($comment->userfirstname); ?> <?php echo e($comment->username); ?> - <?php echo e($comment->usercenter); ?></h5>
									<h6 class="card-subtitle marginbot"><?php echo e($date); ?> <?php echo e($time); ?></h6>
									<p class="card-text"><?php echo e($comment->content); ?></p>
								</div>
							</div>
						</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<li class="list-group-item">
							<div class="card noborder">
								<div class="card-body">
									<p class="card-text">Pas de commentaire à afficher</p>
								</div>
							</div>
						</li>
						<?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
<script >
 function like(IDimg,liked){
 		
		if(liked != 1){

				if(liked === 2 ){
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteimg/'+IDimg+'/' + <?php echo e(Session::get('ID')); ?>+'/'+"<?php echo e($token); ?>" ,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
				}	
	 		$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/img/like/'+"<?php echo e($token); ?>" ,
	 				data: {
	 					"IDVoteimg" : IDimg,
	 					"IDuser" : <?php echo e(Session::get('ID')); ?>,
	 				},
	 				dataType: 'json',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}	
			 });
	 		console.log('like');
 	}else{
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteimg/'+IDimg+'/' + <?php echo e(Session::get('ID')); ?>+ '/'+"<?php echo e($token); ?>" ,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
 	}	
 	location.href = <?php echo e($image->IDimg); ?>;
 	}
 	
 

</script>	
<script >
	function dislike(IDimg, liked){
		
		if(liked != 2){
			console.log('dislike');
				if(liked === 1 ){
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteimg/'+IDimg+'/' +<?php echo e(Session::get('ID')); ?>+'/'+"<?php echo e($token); ?>" ,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
			 	
				}
	 		$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/img/dislike/'+"<?php echo e($token); ?>",
	 				data: {
	 					"IDVoteimg" : IDimg,
	 					"IDuser" : <?php echo e(Session::get('ID')); ?>,
	 				},
	 				dataType: 'json',	
			 success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}	
			 });
		 }else{
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteimg/'+IDimg+'/' + <?php echo e(Session::get('ID')); ?> + '/'+"<?php echo e($token); ?>" ,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
 	} 
 	location.href = <?php echo e($image->IDimg); ?>;
		}
		
</script>

<script>
	$(document).ready(()=>{
	 		$('#postCommentImg').submit((event)=>{
	 			event.preventDefault();
	 			$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/image/addcomment/'+"<?php echo e(Session::get('token')); ?>" ,
	 				data: {
						"content" : $("#newcomment").val(),
	 					"IDuser" : <?php echo e(Session::get('ID')); ?>,
	 					"ts": "<?php echo e($timepost); ?>",
	 					"IDimg" : <?php echo e($image->IDimg); ?>,
	 				},
	 				dataType: 'json',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}
	 			});
				location.href = <?php echo e($image->IDimg); ?>;
	 		}); 
	 		 	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>