<?php $__env->startSection('content'); ?>
<div class="container mb-4">
	<div class="row">
		<div class="col-12">
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th scope="col"> </th>
							<th scope="col">Article</th>
							<th scope="col">Disponibilité</th>
							<th scope="col" class="text-center">Quantité</th>
							<th scope="col" class="text-right">Prix</th>
							<th> </th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><img src="http://placehold.it/50x50" /> </td>
							<td>Pull :)</td>
							<td>En stock</td>
							<td class="text-center">1</td>
							<td class="text-right">124,90 €</td>
							<td class="text-right"><button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> </button> </td>
						</tr>
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td><strong>Total</strong></td>
							<td class="text-right"><strong>346,90 €</strong></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		<div class="col mb-2">
			<div class="row margintop">
				<div class="col-sm-12  col-md-6">
					<button class="btn btn-block btn-light marginbot">Continuer sur la boutique</button>
				</div>
				<div class="col-sm-12 col-md-6 text-right marginbot">
					<button class="btn btn-lg btn-block btn-success text-uppercase">Valider</button>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>