<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row marginbot">
		<div class="col-md-10 offset-md-1">
			<h2 class="pagetitle">Evènements</h2>
			<hr class="separatortitle">
		</div>
	</div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div id="carousel" class="carousel slide carousel-fade" data-ride="carousel" data-interval="6000">
				<ol class="carousel-indicators">
					<li data-target="#carousel" data-slide-to="0" class="active"></li>
					<li data-target="#carousel" data-slide-to="1"></li>
					<li data-target="#carousel" data-slide-to="2"></li>
				</ol>
				<div class="carousel-inner" role="listbox">
					<div class="carousel-item active">
						<a href="#">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							<div class="carousel-caption">
								<div>
									<h2>Test</h2>
									<p>Lorem ipsum dolor sit amet.</p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
					<div class="carousel-item">
						<a href="#">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							<div class="carousel-caption justify-content-center align-items-center">
								<div>
									<h2>Test</h2>
									<p>Lorem ipsum dolor sit amet.</p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
					<div class="carousel-item">
						<a href="#">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							
							<div class="carousel-caption justify-content-center align-items-center">
								<div>
									<h2>Test</h2>
									<p>Lorem ipsum dolor sit amet.</p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
				</div>
				<!-- /.carousel-inner -->
				<a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-2 margintop">
						<div class="card">
							<div class="card-header">
								Filtrer
							</div>
							<div class="card-body">
								<form>
									<div class="form-group">
										<div class="form-check">
											<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
											<label class="form-check-label" for="defaultCheck1">
												Bientôt
											</label>
										</div>
										<div class="form-check">
											<input class="form-check-input" type="checkbox" value="" id="defaultCheck2">
											<label class="form-check-label" for="defaultCheck2">
												Déjà passés
											</label>
										</div>
									</div>
									<div class="form-row">
										<button type="submit" class="btn btn-secondary">
										Filtrer
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-md-10">
						<div class="container-fluid margintop">
							<div class="row">
								<div class="col-md-6">
									<div class="card">
										<div class="container-fluid">
											<div class="row">
												<div class="col-md-6">
													<div class="card-body">
														<h5 class="card-title"><a href="<?php echo e(url('/event')); ?>">Afterwork #6</a></h5>
														<h6 class="card-subtitle mb-2 text-muted">Hebdomadaire - Gratuit</h6>
														<p class="card-text">RDV Delirium</p>
													</div>
												</div>
												<div class="col-md-6 margintop marginbot d-flex justify-content-center">
													<a href="<?php echo e(url('/event')); ?>"><img srcset="http://placehold.it/100" alt="responsive image" class="d-block img-fluid"></a>
												</div>
											</div>
										</div>
										<div class="card-footer text-muted">
											Il y a 2 jours
											<span class="badge badge-pill badge-warning">Presque complet</span>
											<div class="float-right">
												<a href="#" class="btn btn-outline-secondary">Participer</a>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="card">
										<div class="container-fluid">
											<div class="row">
												<div class="col-md-6">
													<div class="card-body">
														<h5 class="card-title"><a href="#">Afterwork #6</a></h5>
														<h6 class="card-subtitle mb-2 text-muted">Hebdomadaire - Gratuit</h6>
														<p class="card-text">RDV Delirium</p>
													</div>
												</div>
												<div class="col-md-6 margintop marginbot d-flex justify-content-center">
													<a href="#"><img srcset="http://placehold.it/100" alt="responsive image" class="d-block img-fluid"></a>
												</div>
											</div>
										</div>
										<div class="card-footer text-muted">
											Il y a 2 jours
											<span class="badge badge-pill badge-warning">Presque complet</span>
											<div class="float-right">
												<a href="#" class="btn btn-outline-secondary">Participer</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row margintop" id="formevent">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Formulaire de création
				</div>
				<div class="card-body">
					<form>
						<div class="form-group row">
							<label for="eventname" class="col-md-2 col-form-label">Nom de l'évènement</label>
							<div class="col-md-10">
								<input type="text" class="form-control" maxlength="25" id="eventname" placeholder="25 caractères max.">
							</div>
						</div>
						<div class="form-group row">
							<label for="eventshortdesc" class="col-md-2 col-form-label">Description courte de l'évenement</label>
							<div class="col-md-10">
								<textarea class="form-control" rows="2" maxlength="250" id="eventshortdesc" placeholder="250 caractères max."></textarea>
							</div>
						</div>
						<div class="form-group row">
							<label for="eventdate" class="col-md-2 col-form-label">Date de l'évenement</label>
							<div class="col-md-10">
								<input type="date" class="form-control" id="eventdate"/>
							</div>
						</div>
						<div class="form-group row">
							<label for="eventimg" class="col-md-2 col-form-label">Image de l'évènement</label>
							<div class="col-md-10">
								<input type="file" class="form-control-file" id="eventimg">
							</div>
						</div>
						<div class="form-group row">
							<label for="eventlongdesc" class="col-md-2 col-form-label">Description complète de l'évenement</label>
							<div class="col-md-10">
								<textarea class="form-control" maxlength="1500" rows="5" id="eventlongdesc" placeholder="1500 caractères max."></textarea>
							</div>
						</div>
						<div class="form-group row">
							<label for="eventprice" class="col-md-2 col-form-label">Prix de l'évènement</label>
							<div class="col-md-10">
								<div class="input-group mb-3">
									<input type="text" class="form-control" maxlength="3" id="eventprice" placeholder="Jusqu'à 999€.">
									<div class="input-group-append">
										<span class="input-group-text">€</span>
									</div>
								</div>
							</div>
						</div>
						<div class="text-center">
							<button type="submit" class="btn btn-secondary">Ajouter cet évènement</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>