<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row marginbot">
		<div class="col-md-10 offset-md-1">
			<h2 class="pagetitle">Evènements</h2>
			<hr class="separatortitle">
		</div>
	</div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div id="carousel" class="carousel slide carousel-fade" data-ride="carousel" data-interval="6000">
				<ol class="carousel-indicators">
					<li data-target="#carousel" data-slide-to="0" class="active"></li>
					<li data-target="#carousel" data-slide-to="1"></li>
					<li data-target="#carousel" data-slide-to="2"></li>
				</ol>
				<div class="carousel-inner" role="listbox">
					<div class="carousel-item active">
						<a href="event/<?php echo e($events[0]->IDevent); ?>">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							<div class="carousel-caption">
								<div>
									<h2><?php echo e($topEvents[0]->name); ?></h2>
									<p><?php echo e($topEvents[0]->description); ?></p>
									<?php
										$date = explode("-", $topEvents[0]->date);
										$date = $date[2]."/".$date[1]."/".$date[0];
									?>
									<p><?php echo e($date); ?> - <?php if($topEvents[0]->price == 0): ?> <?php echo e("Gratuit"); ?> <?php else: ?> <?php echo e($topEvents[0]->price.'€'); ?> <?php endif; ?></p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
					<div class="carousel-item">
						<a href="event/<?php echo e($events[1]->IDevent); ?>">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							<div class="carousel-caption justify-content-center align-items-center">
								<div>
									<h2><?php echo e($topEvents[1]->name); ?></h2>
									<p><?php echo e($topEvents[1]->description); ?></p>
									<?php
										$date = explode("-", $topEvents[1]->date);
										$date = $date[2]."/".$date[1]."/".$date[0];
									?>
									<p><?php echo e($date); ?> - <?php if($topEvents[1]->price == 0): ?> <?php echo e("Gratuit"); ?> <?php else: ?> <?php echo e($topEvents[1]->price.'€'); ?> <?php endif; ?></p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
					<div class="carousel-item">
						<a href="event/<?php echo e($events[2]->IDevent); ?>">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							
							<div class="carousel-caption justify-content-center align-items-center">
								<div>
									<h2><?php echo e($topEvents[2]->name); ?></h2>
									<p><?php echo e($topEvents[2]->description); ?></p>
									<?php
										$date = explode("-", $topEvents[2]->date);
										$date = $date[2]."/".$date[1]."/".$date[0];
									?>
									<p><?php echo e($date); ?> - <?php if($topEvents[2]->price == 0): ?> <?php echo e("Gratuit"); ?> <?php else: ?> <?php echo e($topEvents[2]->price.'€'); ?> <?php endif; ?></p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
				</div>
				<!-- /.carousel-inner -->
				<a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-2 margintop">
						<div class="card">
							<div class="card-header">
								Filtres
							</div>
							<div class="card-body">
								<form>
									<div class="form-group">
										<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="form-check">
											<input class="form-check-input" type="checkbox" value="" id="defaultCheck<?php echo e($tag->IDtag); ?>">
											<label class="form-check-label" for="defaultCheck<?php echo e($tag->IDtag); ?>">
												<?php echo e($tag->name); ?>

											</label>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
									<div class="form-row">
										<button type="submit" class="btn btn-secondary">
										Filtrer
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-md-10">
						<div class="container-fluid margintop">
							<div class="row">
								<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
									$date = explode("-", $event->date);
									$showdate = $date[2]."/".$date[1]."/".$date[0];
									$date = $date[2]."-".$date[1]."-".$date[0];
								?>
								<div class="col-md-6 margintop">
									<div class="card">
										<div class="container-fluid">
											<div class="row">
												<div class="col-md-6">
													<div class="card-body">
														<h5 class="card-title"><a href="event/<?php echo e($event->IDevent); ?>"><?php echo e($event->name); ?></a></h5>
														<h6 class="card-subtitle mb-2 text-muted"><?php echo e($event->punctuality); ?> -  <?php if($event->price == 0): ?> <?php echo e("Gratuit"); ?> <?php else: ?> <?php echo e($event->price.'€'); ?> <?php endif; ?></h6>
														<p class="card-text"><?php echo e($event->description); ?></p>
													</div>
												</div>
												<div class="col-md-6 margintop marginbot d-flex justify-content-center">
													<a href="event/<?php echo e($event->IDevent); ?>"><img srcset="http://placehold.it/100" alt="responsive image" class="d-block img-fluid"></a>
												</div>
											</div>
										</div>
										<div class="card-footer text-muted">
											<?php echo e($showdate); ?>

											<?php if($event->past == 1): ?>
											<?php echo('<span class="badge badge-danger">Passé</span>') ?>
											<?php elseif($date == date('d-m-Y')): ?>
											<?php echo('<span class="badge badge-warning">Aujourd\'hui</span>') ?>
											<?php else: ?>
											<?php echo('<span class="badge badge-success">Bientôt</span>') ?>
											<?php endif; ?>
											<?php if( Session::get('connect') != null || Cookie::get('connect') != null ): ?>
											<div class="float-right">
												<a href="#" class="btn btn-outline-secondary" onclick="participer(<?php echo e($event->IDevent); ?>)">Participer</a>
											</div>
											<?php endif; ?>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php if( Session::get('connect') == 3 || Cookie::get('connect') == 3): ?>
	<div class="row margintop" id="formevent">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Formulaire de création
				</div>
				<div class="card-body">
					<form id="formevent">
						<div class="form-group row">
							<label for="eventname" class="col-md-2 col-form-label">Nom de l'évènement</label>
							<div class="col-md-10">
								<input type="text" class="form-control" maxlength="25" id="eventname" name="eventname" placeholder="25 caractères max.">
							</div>
						</div> 
						<div class="form-group row">
							<label for="eventshortdesc" class="col-md-2 col-form-label">Description courte de l'évenement</label>
							<div class="col-md-10">
								<textarea class="form-control" rows="2" maxlength="250" id="eventshortdesc" name="eventshortdesc" placeholder="250 caractères max."></textarea>
							</div>
						</div>
						<div class="form-group row">
							<label for="eventdate" class="col-md-2 col-form-label">Date de l'évenement</label>
							<div class="col-md-10">
								<input type="date" class="form-control" id="eventdate" name="eventdate"/>
							</div>
						</div>
						<div class="form-group row">
							<label for="eventimg" class="col-md-2 col-form-label">Image de l'évènement</label>
							<div class="col-md-10">
								<input type="file" class="form-control-file" id="eventimg" name="eventimg">
							</div>
						</div>
						<div class="form-group row">
							<label for="eventlongdesc" class="col-md-2 col-form-label">Description complète de l'évenement</label>
							<div class="col-md-10">
								<textarea class="form-control" maxlength="1500" rows="5" id="eventlongdesc" name="eventlongdesc" placeholder="1500 caractères max."></textarea>
							</div>
						</div>
						<div class="form-group row">
							<label for="eventprice" class="col-md-2 col-form-label">Prix de l'évènement</label>
							<div class="col-md-10">
								<div class="input-group mb-3">
									<input type="text" class="form-control" maxlength="3" id="eventprice" name="eventprice" placeholder="Jusqu'à 999€.">
									<div class="input-group-append">
										<span class="input-group-text">€</span>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group row">
                            <label for="eventpunctuality" class="col-md-2 col-form-label">Récurrence de l'évènement</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" maxlength="25" id="eventpunctuality" name="eventpunctuality" placeholder="25 caractères max.">
                            </div>
                        </div>
						<div class="text-center">
							<button type="submit" class="btn btn-secondary">Ajouter cet évènement</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<?php endif; ?>
	 <script>	 
	 	function participer(IDevent){
	 		$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/event/attend/',
	 				data: {
						"IDevent" : IDevent,
						"IDuser" : <?php echo e(Session::get('ID')); ?>	
	 				},
	 				dataType: 'json',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}
	 			});
	 	} 

	 	$(document).ready(()=>{
	 		$('#formevent').submit((event)=>{
	 			event.preventDefault();
	 			$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/event/addevent/',
	 				data: {
						"name" : $("#eventname").val(),
						"description" : $("#eventshortdesc").val(),	
						"date" : $("#eventdate").val(),
	 					"content" : $("#eventlongdesc").val(),
	 					"IDuser" : <?php echo e(Session::get('ID')); ?>,
	 					"ts": "<?php echo e($time); ?>",
	 					"price" : $("#eventprice").val(),
	 					"punctuality": $("#eventpunctuality").val(),
	 				},
	 				dataType: 'json',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}
	 			});
	 		});
	 	});
</script> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>