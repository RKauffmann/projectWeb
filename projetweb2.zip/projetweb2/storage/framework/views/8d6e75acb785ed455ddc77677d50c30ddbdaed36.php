<?php echo e($user->name); ?> <?php echo e($user->first_name); ?> a effectué la commande suivante : <br>
<table class="table table-striped">
	<thead>
		<tr>
			<th scope="col">Article</th>
			<th scope="col">Disponibilité</th>
			<th scope="col" class="text-center">Quantité</th>
			<th scope="col" class="text-right">Prix unitaire</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($order->title); ?></td>
				<td>En stock</td>
				<td class="text-center"><?php echo e($order->quantity); ?></td>
				<td class="text-right"><?php echo e($order->price); ?> €</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><strong>Total</strong></td>
			<td class="text-right"><strong><?php echo e($totalPrice); ?> €</strong></td>
		</tr>
	</tbody>
</table>