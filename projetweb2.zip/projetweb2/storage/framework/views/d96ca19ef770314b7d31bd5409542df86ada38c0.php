<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="container-fluid">
				<div class="row">
					<div class="container-fluid">
                        <div class="row margintop marginbot">
                            <div class="col-md-3 ml-auto">
                                <form>
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" placeholder="Votre recherche" aria-label="Votre recherche" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-secondary" type="button">Rechercher</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-1">
                                <a href="<?php echo e(route('cart')); ?>" class="btn btn-outline-secondary"><i class="fas fa-shopping-cart"></i> Panier</a>
                            </div>
                        </div>
                    </div>
				</div>
				<div class="row">
					<div class="col-md-2">
						<div class="card">
							<div class="card-header">
								Catégories
							</div>
							<div class="card-body">
								<form method="post" action="<?php echo e(route('filtreShop')); ?>">
								<?php echo e(csrf_field()); ?>

									<div class="form-group">
										<div class="pull-right">
											<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="form-check">
												<input checked="checked" name="filtre" class="form-check-input" type="radio" value="<?php echo e($tag->IDtag); ?>" id="filtre<?php echo e($tag->IDtag); ?>">
												<label class="form-check-label" for="filtre<?php echo e($tag->IDtag); ?>">
													<?php echo e($tag->name); ?>

												</label>
											</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
										<div class="pull-right">
											<div class="form-check">
												<input name="triPrix" class="form-check-input" type="radio" value="ASC" id="tri">
												<label class="form-check-label" for="tri">
													prix croissant
												</label>
											</div>
											<div class="form-check">
												<input name="triPrix" class="form-check-input" type="radio" value="DESC" id="tri">
												<label class="form-check-label" for="tri">
													prix decroissant
												</label>
											</div>
										</div>
									</div>
									<div class="form-row">
										<button type="submit" class="btn btn-secondary">
										Filtrer
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-md-10">
						<div class="container-fluid">
							<div class="row">
								<div class="col-md-12">
									<div id="carousel" class="carousel slide carousel-fade" data-ride="carousel" data-interval="6000">
										<ol class="carousel-indicators">
											<li data-target="#carousel" data-slide-to="0" class="active"></li>
											<li data-target="#carousel" data-slide-to="1"></li>
											<li data-target="#carousel" data-slide-to="2"></li>
										</ol>
										<!-- /.carousel-item -->
										<div class="carousel-inner" role="listbox">
											<div class="carousel-item active">
												<a href="#">
													<img srcset="/storage/<?php echo e($topArticles[0]->thumbnail); ?>" alt="responsive image" class="d-block img-fluid">
													<div class="carousel-caption">
														<div>
															<h2><?php echo e($topArticles[0]->title); ?></h2>
															<p><?php echo e($topArticles[0]->nbSell); ?> articles vendus</p>
															<span class="btn btn-sm btn-outline-secondary">Voir</span>
														</div>
													</div>
												</a>
											</div>
											<!-- /.carousel-item -->
											<div class="carousel-item">
												<a href="#">
													<img srcset="/storage/<?php echo e($topArticles[1]->thumbnail); ?>" alt="responsive image" class="d-block img-fluid">
													<div class="carousel-caption justify-content-center align-items-center">
														<div>
															<h2><?php echo e($topArticles[1]->title); ?></h2>
															<p><?php echo e($topArticles[1]->nbSell); ?> articles vendus</p>
															<span class="btn btn-sm btn-outline-secondary">Voir</span>
														</div>
													</div>
												</a>
											</div>
											<!-- /.carousel-item -->
											<div class="carousel-item">
												<a href="#">
													<img srcset="/storage/<?php echo e($topArticles[2]->thumbnail); ?>" alt="responsive image" class="d-block img-fluid">
													
													<div class="carousel-caption justify-content-center align-items-center">
														<div>
															<h2><?php echo e($topArticles[2]->title); ?></h2>
															<p><?php echo e($topArticles[2]->nbSell); ?> articles vendus</p>
															<span class="btn btn-sm btn-outline-secondary">Voir</span>
														</div>
													</div>
												</a>
											</div>
											<!-- /.carousel-item -->
										</div>
										<!-- /.carousel-inner -->
										<a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
											<span class="carousel-control-prev-icon" aria-hidden="true"></span>
											<span class="sr-only">Previous</span>
										</a>
										<a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
											<span class="carousel-control-next-icon" aria-hidden="true"></span>
											<span class="sr-only">Next</span>
										</a>
									</div>
								</div>
							</div>

							<div class="row margintop">
								<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-lg-4 col-md-6 mb-4">
									<div class="card h-100">
										<a href="article/<?php echo e($article->IDarticle); ?>"><img class="card-img-top" src="/storage/<?php echo e($article->thumbnail); ?>" alt=""></a>
										<div class="card-body">
											<h4 class="card-title">
											<a href="article/<?php echo e($article->IDarticle); ?>"><?php echo e($article->title); ?></a>
											</h4>
											<h5><?php echo e($article->price); ?>€</h5>
											<p class="card-text"><?php echo e($article->description); ?></p>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php if( Session::get('connect') == 3 ): ?>
	<div class="row margintop" id="formArticle">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Formulaire de création
				</div>
				<div class="card-body">
					<form method="post" action="<?php echo e(route('newArticle')); ?>" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<div class="form-group row">
							<label for="articleName" class="col-md-2 col-form-label">Nom de l'article</label>
							<div class="col-md-10">
								<input type="text" class="form-control" maxlength="25" id="articleName" name="articleName" placeholder="25 caractères max.">
							</div>
						</div> 
						<div class="form-group row">
							<label for="articleDesc" class="col-md-2 col-form-label">Description de l'article</label>
							<div class="col-md-10">
								<textarea class="form-control" rows="2" maxlength="250" id="articleDesc" name="articleDesc" placeholder="250 caractères max."></textarea>
							</div>
						</div>
						<div class="form-group row">
							<label for="articleimg" class="col-md-2 col-form-label">Image de l'article</label>
							<div class="col-md-10">
								<input type="file" class="form-control-file"  name="articleimg">
							</div>
						</div>
						<div class="form-group row">
							<label for="articlePrice" class="col-md-2 col-form-label">Prix de l'article</label>
							<div class="col-md-10">
								<div class="input-group mb-3">
									<input type="text" class="form-control" maxlength="3" id="articlePrice" name="articlePrice" placeholder="Jusqu'à 999€.">
									<div class="input-group-append">
										<span class="input-group-text">€</span>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group row">
							<label for="articleStock" class="col-md-2 col-form-label">Nombre d'article en stock</label>
							<div class="col-md-10">
								<input type="text" class="form-control" maxlength="25" id="articleStock" name="articleStock">
							</div>
						</div>
						<div class="form-group row">
							<label for="articleStock" class="col-md-2 col-form-label">tags : </label>
							<div class="col-md-10">
								<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="form-check">
										<input name="<?php echo e($tag->name); ?>" class="form-check-input" type="checkbox" value="<?php echo e($tag->IDtag); ?>" id="<?php echo e($tag->IDtag); ?>">
										<label class="form-check-label" for="<?php echo e($tag->IDtag); ?>">
											<?php echo e($tag->name); ?>

										</label>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						<div class="text-center">
							<button type="submit" class="btn btn-secondary">Ajouter cet article</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>