<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<div class="row marginbot">
		<div class="col-md-10 offset-md-1">
			<h2 class="pagetitle">Event</h2>
			<hr class="separatortitle">
		</div>
	</div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="card cardArticle">
				<div class="container-fluid">
					<div class="wrapper row">
						<div class="preview col-md-5">
							<div class="preview-pic tab-content">
								<div class="tab-pane active" id="pic-1"><img src="/storage/<?php echo e($event->thumbnail); ?>" /></div>
							</div>
						</div>
						<div class="details col-md-7">
							<?php
								$date = explode("-", $event->date);
								$date = $date[2]."/".$date[1]."/".$date[0];
							?>
							<h3 class="product-title"><?php echo e($event->name); ?></h3>
							<p class="product-description"><?php echo e($event->description); ?></p>
							<h4>Date : <span><?php echo e($date); ?> - <?php echo e($event->punctuality); ?></span></h4>
							<h4 class="price">Prix : <span><?php if($event->price == 0): ?> <?php echo e("Gratuit"); ?> <?php else: ?> <?php echo e($event->price.'€'); ?> <?php endif; ?></span></h4>
							<p class="product-description">
								<?php echo e($event->content); ?>

							</p>
							<?php if( Session::get('connect') != null && $event->past == 0): ?>
							<div class="action">
								<button class="add-to-cart btn btn-outline-secondary" type="button">Participer</button>
							</div>
							<?php endif; ?>
							<?php if(Session::get('connect') == 2): ?>
							<a  onclick= "location.href='/sendMailEventImg/<?php echo e($event->IDevent); ?>'" class="btn btn-outline-warning"><i class="fas lamation"></i> Signaler</a>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php if($event->past == 1 ): ?>
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Photos de l'évènement
				</div>
				<div class="card-body">
					<ul class="list-group list-group-flush">
						<li class="list-group-item">
							<div id="carousel" class="carousel slide carousel-fade" data-ride="carousel" data-interval="6000">
								<ol class="carousel-indicators">
									<li data-target="#carousel" data-slide-to="0"></li>
									<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php $i = 1; ?>
									<li data-target="#carousel" data-slide-to="<?php echo e($i); ?>"></li>
									<?php
									$i++;
									?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ol>
								<div class="carousel-inner" role="listbox">
									<div class="carousel-item active">
										<img src="/storage/<?php echo e($event->thumbnail); ?>" alt="responsive image" class="d-block img-fluid">
										<div class="carousel-caption">
											<div>
												<p>Photo de base</p>
											</div>
										</div>
									</a>
								</div>
								<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="carousel-item ">
									<a href="image/<?php echo e($image->IDimg); ?>">
										<img src="/storage/<?php echo e($image->content); ?>" alt="responsive image" class="d-block img-fluid">
										<div class="carousel-caption">
											<div>
												<a href="image/<?php echo e($image->IDimg); ?>" class="btn btn-outline-secondary">Voir</a>
											</div>
										</div>
									</a>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
								<span class="carousel-control-prev-icon" aria-hidden="true"></span>
								<span class="sr-only">Previous</span>
							</a>
							<a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
								<span class="carousel-control-next-icon" aria-hidden="true"></span>
								<span class="sr-only">Next</span>
							</a>
						</div>
					</li>
					<?php if($event->attendee): ?>
					<li class="list-group-item">
						
							<form method="post" action="/event/addimg/<?php echo e($event->IDevent); ?>" enctype="multipart/form-data">
                       	     <?php echo e(csrf_field()); ?>

                       	     <label class="label">Ajouter une photo à l'évènement</label>
                       	     <div class="control">
                       	         <input type="file" name="eventImg" class="form-control-file marginbot">
                       	     </div>
                       	     <button type="submit" class="btn btn-secondary">Valider</button>
                       	     <?php if($errors->has('eventImg')): ?>
                       	     	<p class="help is-danger"><?php echo e($errors->first('eventImg')); ?></p>
                      	     <?php endif; ?>
                      	  </form>
                        <?php endif; ?>	
					</li>
				</ul>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>
<?php if( Session::get('connect') != null): ?>
<div class="row margintop">
	<div class="col-md-10 offset-md-1">
		<div class="card">
			<div class="card-header">
				Poster un commentaire
			</div>
			<div class="card-body">
				<form id="formcom">
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<div class="form-group">
							<label for="exampleFormControlTextarea1">Votre commentaire :</label>
							<textarea class="form-control" id="newcomment" rows="3"></textarea>
						</div>
						<div class="d-flex justify-content-center">
							<button type="submit" class="btn btn-outline-secondary">Envoyer</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>
<div class="row margintop">
	<div class="col-md-10 offset-md-1">
		<div class="card">
			<div class="card-header">
			</div>
			<div class="card-body">
				<ul class="list-group list-group-flush">
					<?php if(!empty($comments[0])): ?>
					<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php
						$sep = explode(" ", $comment->ts);
						$time = $sep[1];
						$date = explode("-", $sep[0]);
						$date = $date[2]."/".$date[1]."/".$date[0];
					?>
					<li class="list-group-item">
						<div class="card noborder">
							<div class="card-body">
								<h5 class="card-title marginbot"><?php echo e($comment->userfirstname); ?> <?php echo e($comment->username); ?> - <?php echo e($comment->usercenter); ?></h5>
								<h6 class="card-subtitle marginbot"><?php echo e($date); ?> <?php echo e($time); ?></h6>
								<p class="card-text"><?php echo e($comment->content); ?></p>
							</div>
						</div>
					</li>
					<?php if(Session::get('connect') == 2): ?>
					<a  onclick= "location.href='/sendMailComment/<?php echo e($event->IDevent); ?>'" class="btn btn-outline-warning"><i class="fas lamation"></i> Signaler</a>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					<li class="list-group-item">
						<div class="card noborder">
							<div class="card-body">
								<p class="card-text">Pas de commentaire à afficher</p>
							</div>
						</div>
					</li>
					<?php endif; ?>
				</ul>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(()=>{
			$('#formcom').submit((event)=>{
				event.preventDefault();
				$.ajax({
					type: 'POST',
					url: 'http://localhost:3000/event/addcomment/'+"<?php echo e(Session::get('token')); ?>" ,
					data: {
						"content" : $("#newcomment").val(),
						"IDuser" : <?php echo e(Session::get('ID')); ?>,
						"ts": "<?php echo e($timepost); ?>",
						"IDevent" : <?php echo e($event->IDevent); ?>,
					},
					dataType: 'json',
					success : (data)=>{
						console.log(data);
					},
					error : (data, status)=>{
						console.log(data);
					}
				});
				location.href = '/event/'+ <?php echo e($event->IDevent); ?>;
			});
				});
</script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>