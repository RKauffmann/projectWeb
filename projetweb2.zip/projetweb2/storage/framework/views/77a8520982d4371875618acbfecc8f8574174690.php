<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<div class="container-fluid">
	<div class="row marginbot">
		<div class="col-md-10 offset-md-1">
			<h2 class="pagetitle">Boîte à idées</h2>
			<hr class="separatortitle">
		</div>
	</div>
	

	<?php if( Session::get('connect') != null): ?>
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="alert alert-secondary text-center" role="alert">
				Pour proposer une idée, merci d'utiliser <a href="#formevent" class="alert-link">ce formulaire</a>. Votre proposition sera étudiée par les membres du BDE et une réponse vous sera envoyée sur votre adresse mail.
				</button>
			</div>
		</div>
	</div>
	<?php endif; ?>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-2 margintop">
						<div class="card">
							<div class="card-header">
								Filtrer
							</div>
							<div class="card-body">
								<form method="POST" action="<?php echo e(route('filtreIdea')); ?>">
									<?php echo e(csrf_field()); ?>

									<div class="form-group">
										<div class="pull-right">
											<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="form-check">
												<input class="form-check-input" type="radio" value="<?php echo e($tag->IDtag); ?>" id="filtre<?php echo e($tag->IDtag); ?>" name="filtre" checked="checked">
												<label class="form-check-label" for="filtre<?php echo e($tag->IDtag); ?>">
													<?php echo e($tag->name); ?>

												</label>
											</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									</div>
									<div class="form-row">
										<button type="submit" class="btn btn-secondary">
										Filtrer
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-md-10">
						<div class="container-fluid margintop">
							<div class="row" id="refreshdiv">
								<?php $__currentLoopData = $ideas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
								<div class="col-sm-6">
									<div class="card">
										<div class="container-fluid">
											<div class="row">
												<div class="col-md-6">
													<div class="card-body">
														<h5 class="card-title"><?php echo e($idea->title); ?></h5>
														<p class="card-text"><?php echo e($idea->content); ?></p>
													</div>
												</div>
											</div>
										</div>
										<div class="card-footer text-muted">
												<?php if($idea->liked == 1): ?>
											<a  id="like<?php echo e($idea->IDidea); ?>" href="javascript:like(<?php echo e($idea->IDidea); ?>,<?php echo e($idea->liked); ?>)" class="btn btn-outline-primary">
											<?php else: ?>
											<a  id="like<?php echo e($idea->IDidea); ?>" href="javascript:like(<?php echo e($idea->IDidea); ?>,<?php echo e($idea->liked); ?>)" class="btn btn-outline-secondary">
											<?php endif; ?>
												<i class="fas fa-thumbs-up"></i>  <span  class="likes"><?php echo e($idea->nblike); ?></span></a>
											

													

											<?php if($idea->liked != 1): ?>
											<a id="dislike<?php echo e($idea->IDidea); ?>" href="javascript:dislike(<?php echo e($idea->IDidea); ?>,<?php echo e($idea->liked); ?>)" class="btn btn-outline-secondary">
											<?php else: ?> 
											<a id="dislike<?php echo e($idea->IDidea); ?>" href="javascript:dislike(<?php echo e($idea->IDidea); ?>,<?php echo e($idea->liked); ?>)" class="btn btn-outline-danger">
											<?php endif; ?>
											<i class="fas fa-thumbs-down"></i>  <span class="dislikes"><?php echo e($idea->nbdislike); ?></span></a>


											 <?php if( Session::get('connect') == 3): ?>
											<div class="float-right">
												<a  onclick="Valider(<?php echo e($idea->IDidea); ?>)"class="btn btn-outline-secondary">Valider</a>
											</div>
											<?php endif; ?>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	 <?php if( Session::get('connect') != null): ?>
	<div class="row margintop" id="formevent">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Formulaire de proposition
				</div>
				<div class="card-body">
					<form id="formaddidea">
						<?php echo csrf_field(); ?>
						<div class="form-group row">
							<label for="ideaname" class="col-md-2 col-form-label">Titre de l'idée</label>
							<div class="col-md-10">
								<input type="text" class="form-control" maxlength="25" name="ideaname" id="ideaname" placeholder="25 caractères max.">
							</div>
						</div>
						<div class="form-group row">
							<label for="ideadesc" class="col-md-2 col-form-label">Description de l'idée</label>
							<div class="col-md-10">
								<textarea class="form-control" rows="5" maxlength="280" name="ideadesc" id="ideadesc" placeholder="280 caractères max."></textarea>
							</div>
						</div>
						<div class="text-center">
							<button type="submit" href="<?php echo e(route('idea')); ?>" class="btn btn-secondary" id="btnaddidea">Proposer cette idée</button>
						</div >
					</form>
				</div>
			</div>
		</div>
	</div>
	<?php endif; ?>
	 <script>	 
	 	$(document).ready(()=>{
	 		$('#formaddidea').submit((event)=>{
	 			event.preventDefault();
	 			$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/idea',
	 				data: {
	 					"title" : $("#ideaname").val(),
	 					"content" : $("#ideadesc").val(),
	 					"IDuser" : <?php echo e(Session::get('ID')); ?>,
	 					"ts": "<?php echo e($time); ?>"
	 				},
	 				dataType: 'json',
	 				error : (data, status)=>{
	 					console.log(data);
	 				}
	 			});
	 		});
	 	});

</script> 
<script >
 function like(IDidea,liked){
 	if(<?php echo e(Session::get('connect')); ?> != null){
		if(liked != 1){
				if(liked === 0 ){

		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteidea/'+IDidea+'/' + <?php echo e(Session::get('ID')); ?>,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
				}	
	 		$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/idea/like',
	 				data: {
	 					"IDidea" : IDidea,
	 					"IDuser" : <?php echo e(Session::get('ID')); ?>,
	 				},
	 				dataType: 'json',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}	
			 });
 	}else{
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteidea/'+IDidea+'/' + <?php echo e(Session::get('ID')); ?>,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
 	}	
 	}
 	$('#refreshdiv').load('refreshidea');
}   

</script>	
<script >
	function dislike(IDidea,liked){
		if(<?php echo e(Session::get('connect')); ?> !=  null){
		if(liked != 0){
				if(liked === 1 ){
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteidea/'+IDidea+'/' +<?php echo e(Session::get('ID')); ?>,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
			 	
				}
	 		$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/idea/dislike',
	 				data: {
	 					"IDidea" : IDidea,
	 					"IDuser" : <?php echo e(Session::get('ID')); ?>,
	 				},
	 				dataType: 'json',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}	
			 });
		 }else{
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteidea/'+IDidea+'/' + <?php echo e(Session::get('ID')); ?>,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
 	}
		}
		$('#refreshdiv').load('refreshidea');
}
</script>
<script >
	function Valider(IDidea){
	 		$.ajax({
	 				type: 'DELETE',
	 				url: 'http://localhost:3000/valididea/' + IDidea + '/',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}	
			 });
	 		$('#refreshdiv').load('refreshidea');
		 }
</script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>