<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row marginbot">
		<div class="col-md-10 offset-md-1">
			<h2 class="pagetitle">Boîte à idées</h2>
			<hr class="separatortitle">
		</div>
	</div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div id="carousel" class="carousel slide carousel-fade" data-ride="carousel" data-interval="6000">
				<ol class="carousel-indicators">
					<li data-target="#carousel" data-slide-to="0" class="active"></li>
					<li data-target="#carousel" data-slide-to="1"></li>
					<li data-target="#carousel" data-slide-to="2"></li>
				</ol>
				<div class="carousel-inner" role="listbox">
					<div class="carousel-item active">
						<a href="#">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							<div class="carousel-caption">
								<div>
									<h2>Test</h2>
									<p>Lorem ipsum dolor sit amet.</p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
					<div class="carousel-item">
						<a href="#">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							<div class="carousel-caption justify-content-center align-items-center">
								<div>
									<h2>Test</h2>
									<p>Lorem ipsum dolor sit amet.</p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
					<div class="carousel-item">
						<a href="#">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							
							<div class="carousel-caption justify-content-center align-items-center">
								<div>
									<h2>Test</h2>
									<p>Lorem ipsum dolor sit amet.</p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
				</div>
				<!-- /.carousel-inner -->
				<a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
		</div>
	</div>
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="alert alert-secondary text-center" role="alert">
				Pour proposer une idée, merci d'utiliser <a href="#formevent" class="alert-link">ce formulaire</a>. Votre proposition sera étudiée par les membres du BDE et une réponse vous sera envoyée sur votre adresse mail.
				</button>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-2 margintop">
						<div class="card">
							<div class="card-header">
								Filtrer
							</div>
							<div class="card-body">
								<form>
									<div class="form-group">
										<div class="form-check">
											<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
											<label class="form-check-label" for="defaultCheck1">
												Validées
											</label>
										</div>
										<div class="form-check">
											<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
											<label class="form-check-label" for="defaultCheck1">
												Refusées
											</label>
										</div>
										<div class="form-check">
											<input class="form-check-input" type="checkbox" value="" id="defaultCheck2">
											<label class="form-check-label" for="defaultCheck2">
												A valider
											</label>
										</div>
									</div>
									<div class="form-row">
										<button type="submit" class="btn btn-secondary">
										Filtrer
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-md-10">
						<div class="container-fluid margintop">
							<div class="row">
								<div class="col-sm-6">
									<div class="card">
										<div class="container-fluid">
											<div class="row">
												<div class="col-md-6">
													<div class="card-body">
														<h5 class="card-title">Afterwork #6</h5>
														<p class="card-text">RDV Delirium</p>
													</div>
												</div>
											</div>
										</div>
										<div class="card-footer text-muted">
											<a href="#" class="btn btn-outline-secondary"><i class="fas fa-thumbs-up"></i>  <span class="likes">1</span></a>
											<a href="#" class="btn btn-outline-secondary"><i class="fas fa-thumbs-down"></i>  <span class="dislikes">0</span></a>
											<div class="float-right">
												<a href="#" class="btn btn-outline-secondary">Valider</a>
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="card">
										<div class="container-fluid">
											<div class="row">
												<div class="col-md-6">
													<div class="card-body">
														<h5 class="card-title">Afterwork #6</h5>
														<p class="card-text">RDV Delirium</p>
													</div>
												</div>
											</div>
										</div>
										<div class="card-footer text-muted">
											<a href="#" class="btn btn-outline-secondary"><i class="fas fa-thumbs-up"></i>  <span class="likes">1</span></a>
											<a href="#" class="btn btn-outline-secondary"><i class="fas fa-thumbs-down"></i>  <span class="dislikes">0</span></a>
											<div class="float-right">
												<a href="#" class="btn btn-outline-secondary">Valider</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row margintop" id="formevent">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Formulaire de proposition
				</div>
				<div class="card-body">
					<form>
						<div class="form-group row">
							<label for="ideaname" class="col-md-2 col-form-label">Titre de l'idée</label>
							<div class="col-md-10">
								<input type="text" class="form-control" maxlength="25" id="ideaname" placeholder="25 caractères max.">
							</div>
						</div>
						<div class="form-group row">
							<label for="ideadesc" class="col-md-2 col-form-label">Description de l'idée</label>
							<div class="col-md-10">
								<textarea class="form-control" rows="5" maxlength="280" id="ideadesc" placeholder="280 caractères max."></textarea>
							</div>
						</div>
						<div class="text-center">
							<button type="submit" class="btn btn-secondary">Proposer cette idée</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>