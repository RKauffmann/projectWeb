<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">

        <title>Document</title>

        <style type="text/css">
           body,html{
            height: 100%;
           }
           body{
            display: flex;
            justify-content: center;
            align-items: center;
           }
        </style>
    </head>
    <body class="container">
        <form method="POST" action="/avatars" enctype="multipart/from-data">
            <?php echo e(csrf_field()); ?>

            <input type="file" name="avatar">
            <input type="submit" > Save avatar</input>
            </form>      
    </body>
</html>
