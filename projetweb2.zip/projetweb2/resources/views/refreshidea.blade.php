<?php
	$ideas = DB::connection('bddbde')->table('idea')->get();
    
        $votelist =  DB::connection('bddbde')->table('voteidea')->Where('IDuser',Session::get('ID'))->get();
    	foreach ($ideas as $key => $idea) {
    		$temp = DB::connection('bddbde')->select('CALL nbvoteidealike('.$idea->IDidea.')');
    		$idea->nblike = $temp[0]->sortie;
    		$temp = DB::connection('bddbde')->select('CALL nbvoteideadislike('.$idea->IDidea.')');
    		$idea->nbdislike = $temp[0]->sortie;
            $idea->liked =  DB::connection('bddbde')->table('voteidea')->Where('IDuser',Session::get('ID'))->Where('IDidea',$idea->IDidea)->value('reaction');
    	}

   
?> 	
@foreach ($ideas as $key => $idea) 
								<div class="col-sm-6">
									<div class="card">
										<div class="container-fluid">
											<div class="row">
												<div class="col-md-6">
													<div class="card-body">
														<h5 class="card-title">{{$idea->title}}</h5>
														<p class="card-text">{{$idea->content}}</p>
													</div>
												</div>
											</div>
										</div>
										<div class="card-footer text-muted">
												@if($idea->liked == 1)
											<a  id="like{{$idea->IDidea}}" href="javascript:like({{$idea->IDidea}},{{$idea->liked}})" class="btn btn-outline-primary">
											@else
											<a  id="like{{$idea->IDidea}}" href="javascript:like({{$idea->IDidea}},{{$idea->liked}})" class="btn btn-outline-secondary">
											@endif
												<i class="fas fa-thumbs-up"></i>  <span  class="likes">{{$idea->nblike}}</span></a>
											

													

											@if($idea->liked == 2)
											<a id="dislike{{$idea->IDidea}}" href="javascript:dislike({{$idea->IDidea}},{{$idea->liked}})" class="btn btn-outline-danger">
											@else 
											<a id="dislike{{$idea->IDidea}}" href="javascript:dislike({{$idea->IDidea}},{{$idea->liked}})" class="btn btn-outline-secondary">
											@endif
											<i class="fas fa-thumbs-down"></i>  <span class="dislikes">{{$idea->nbdislike}}</span></a>


											@if(Session::get('connect') == 3)
										        <a  onclick="location.href='/sendMailValidation/{{$idea->IDidea}}'"class="btn btn-outline-success">Valider</a>
										        <a  class="btn btn-outline-danger">Supprimer</a>
										  		
											@elseif(Session::get('connect') == 2)
												<a  onclick= "location.href='/sendMail/{{$idea->IDidea}}'" class="btn btn-outline-warning"><i class="fas fa-exclamation"></i> Signaler</a>
											@endif
										</div>
									</div>
								</div>
								@endforeach