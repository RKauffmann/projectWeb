@extends('layouts.app')
@section('content')
<?php
$token = Session::get('token');
?>

<div class="container-fluid">
	<div class="row marginbot">
		<div class="col-md-10 offset-md-1">
			<h2 class="pagetitle">Image - {{$image->event}}</h2>
			<hr class="separatortitle">
		</div>
	</div>
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card w-100">
				<div class="card-body">
					<div class="container-fluid">
						<div class="row d-flex justify-content-center marginbot">
							<img src="/storage/{{$image->content}}" alt="Card image cap">
						</div>
						<div class="row d-flex justify-content-center">
							<div class="float-right">
								@if($image->liked == 1)
									<a  id="like{{$image->IDimg}}" href="javascript:like({{$image->IDimg}},{{$image->liked}})" class="btn btn-outline-primary">
								@else
									<a  id="like{{$image->IDimg}}" href="javascript:like({{$image->IDimg}},{{$image->liked}})" class="btn btn-outline-secondary">
								@endif
									<i class="fas fa-thumbs-up"></i>  <span  class="likes">{{$image->nblike}}</span></a>
								@if($image->liked == 2)
									<a id="dislike{{$image->IDimg}}" href="javascript:dislike({{$image->IDimg}},{{$image->liked}})" class="btn btn-outline-danger">
								@else
									<a id="dislike{{$image->IDimg}}" href="javascript:dislike({{$image->IDimg}},{{$image->liked}})" class="btn btn-outline-secondary">
								@endif
								<i class="fas fa-thumbs-down"></i>  <span class="dislikes">{{$image->nbdislike}}</span></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	@if( Session::get('connect') != null)
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Poster un commentaire
				</div>
				<div class="card-body">
					<form id='postCommentImg'>
						<div class="form-group">
							<div class="form-group">
								<label for="exampleFormControlTextarea1">Votre commentaire :</label>
								<textarea class="form-control" id="newcomment" rows="3"></textarea>
							</div>
							<div class="d-flex justify-content-center">
								<button type="submit" class="btn btn-outline-secondary">Envoyer</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	@endif
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Commentaires
				</div>
				<div class="card-body">
					<ul class="list-group list-group-flush">
						@if(!empty($comments[0]))
						@foreach($comments as $comment)
						<?php
							$sep = explode(" ", $comment->ts);
							$time = $sep[1];
							$date = explode("-", $sep[0]);
							$date = $date[2]."/".$date[1]."/".$date[0];
						?>
						<li class="list-group-item">
							<div class="card noborder">
								<div class="card-body">
									<h5 class="card-title marginbot">{{$comment->userfirstname}} {{$comment->username}} - {{$comment->usercenter}}</h5>
									<h6 class="card-subtitle marginbot">{{$date}} {{$time}}</h6>
									<p class="card-text">{{$comment->content}}</p>
								</div>
							</div>
						</li>
						@endforeach
						@else
						<li class="list-group-item">
							<div class="card noborder">
								<div class="card-body">
									<p class="card-text">Pas de commentaire à afficher</p>
								</div>
							</div>
						</li>
						@endif
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
<script >
 function like(IDimg,liked){
 		
		if(liked != 1){

				if(liked === 2 ){
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteimg/'+IDimg+'/' + {{ Session::get('ID') }}+'/'+"{{$token}}" ,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
				}	
	 		$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/img/like/'+"{{$token}}" ,
	 				data: {
	 					"IDVoteimg" : IDimg,
	 					"IDuser" : {{ Session::get('ID') }},
	 				},
	 				dataType: 'json',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}	
			 });
	 		console.log('like');
 	}else{
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteimg/'+IDimg+'/' + {{ Session::get('ID') }}+ '/'+"{{$token}}" ,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
 	}	
 	location.href = {{$image->IDimg}};
 	}
 	
 

</script>	
<script >
	function dislike(IDimg, liked){
		
		if(liked != 2){
			console.log('dislike');
				if(liked === 1 ){
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteimg/'+IDimg+'/' +{{ Session::get('ID') }}+'/'+"{{$token}}" ,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
			 	
				}
	 		$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/img/dislike/'+"{{$token}}",
	 				data: {
	 					"IDVoteimg" : IDimg,
	 					"IDuser" : {{ Session::get('ID') }},
	 				},
	 				dataType: 'json',	
			 success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}	
			 });
		 }else{
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteimg/'+IDimg+'/' + {{ Session::get('ID') }} + '/'+"{{$token}}" ,
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
 	} 
 	location.href = {{$image->IDimg}};
		}
		
</script>

<script>
	$(document).ready(()=>{
	 		$('#postCommentImg').submit((event)=>{
	 			event.preventDefault();
	 			$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/image/addcomment/'+"{{Session::get('token')}}" ,
	 				data: {
						"content" : $("#newcomment").val(),
	 					"IDuser" : {{ Session::get('ID') }},
	 					"ts": "{{$timepost}}",
	 					"IDimg" : {{$image->IDimg}},
	 				},
	 				dataType: 'json',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}
	 			});
				location.href = {{$image->IDimg}};
	 		}); 
	 		 	});
</script>
@endsection