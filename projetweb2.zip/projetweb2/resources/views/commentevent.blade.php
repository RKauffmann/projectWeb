



@foreach($comments as $comment)
						<?php
							$sep = explode(" ", $comment->ts);
							$time = $sep[1];
							$date = explode("-", $sep[0]);
							$date = $date[2]."/".$date[1]."/".$date[0];
						?>
						<li class="list-group-item">
							<div class="card noborder">
								<div class="card-body">
									<h5 class="card-title marginbot">{{$comment->userfirstname}} {{$comment->username}} - {{$comment->usercenter}}</h5>
									<h6 class="card-subtitle marginbot">{{$date}} {{$time}}</h6>
									<p class="card-text">{{$comment->content}}</p>
								</div>
							</div>
						</li>
						@endforeach