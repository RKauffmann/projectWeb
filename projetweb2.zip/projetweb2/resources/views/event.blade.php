@extends('layouts.app')
@section('content')
<div class="container-fluid">
	<div class="row marginbot">
		<div class="col-md-10 offset-md-1">
			<h2 class="pagetitle">Boîte à idées</h2>
			<hr class="separatortitle">
		</div>
	</div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="card cardArticle">
				<div class="container-fluid">
					<div class="wrapper row">
						<div class="preview col-md-5">
							<div class="preview-pic tab-content">
								<div class="tab-pane active" id="pic-1"><img src="http://placehold.it/400x252" /></div>
							</div>
						</div>
						<div class="details col-md-7">
							<?php
								$date = explode("-", $event->date);
								$date = $date[2]."/".$date[1]."/".$date[0];
							?>
							<h3 class="product-title">{{ $event->name }}</h3>
							<p class="product-description">{{ $event->description }}</p>
							<h4>Date : <span>{{ $date }} - {{ $event->punctuality }}</span></h4>
							<h4 class="price">Prix : <span>@if($event->price == 0) {{ "Gratuit" }} @else {{ $event->price.'€' }} @endif</span></h4>
							<p class="product-description">
								{{ $event->content }}
							</p>
							@if( Session::get('connect') != null || Cookie::get('connect') != null )
							<div class="action">
								<button class="add-to-cart btn btn-outline-secondary" type="button">Participer</button>
							</div>
							@endif
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	@if( Session::get('connect') != null || Cookie::get('connect') != null )
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Poster un commentaire
				</div>
				<div class="card-body">
					<form>
						<div class="form-group">
							<div class="form-group">
								<label for="exampleFormControlTextarea1">Votre commentaire :</label>
								<textarea class="form-control" id="newcomment" rows="3"></textarea>
							</div>
							<div class="d-flex justify-content-center">
								<button type="submit" class="btn btn-outline-secondary">Envoyer</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	@endif
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Commentaires
				</div>
				<div class="card-body">
					<ul class="list-group list-group-flush">
						@if(!empty($comments[0]))
						@foreach($comments as $comment)
						<?php
							$sep = explode(" ", $comment->ts);
							$time = $sep[1];
							$date = explode("-", $sep[0]);
							$date = $date[2]."/".$date[1]."/".$date[0];
						?>
						<li class="list-group-item">
							<div class="card noborder">
								<div class="card-body">
									<h5 class="card-title marginbot">{{$comment->userfirstname}} {{$comment->username}} - {{$comment->usercenter}}</h5>
									<h6 class="card-subtitle marginbot">{{$date}} {{$time}}</h6>
									<p class="card-text">{{$comment->content}}</p>
								</div>
							</div>
						</li>
						@endforeach
						@else
						<li class="list-group-item">
							<div class="card noborder">
								<div class="card-body">
									<p class="card-text">Pas de commentaire à afficher</p>
								</div>
							</div>
						</li>
						@endif
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection