@extends('layouts.app')
@section('content')
<div class="container-fluid">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<div class="row marginbot">
		<div class="col-md-10 offset-md-1">
			<h2 class="pagetitle">Event</h2>
			<hr class="separatortitle">
		</div>
	</div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="card cardArticle">
				<div class="container-fluid">
					<div class="wrapper row">
						<div class="preview col-md-5">
							<div class="preview-pic tab-content">
								<div class="tab-pane active" id="pic-1"><img src="/storage/{{$event->thumbnail}}" /></div>
							</div>
						</div>
						<div class="details col-md-7">
							<?php
								$date = explode("-", $event->date);
								$date = $date[2]."/".$date[1]."/".$date[0];
							?>
							<h3 class="product-title">{{ $event->name }}</h3>
							<p class="product-description">{{ $event->description }}</p>
							<h4>Date : <span>{{ $date }} - {{ $event->punctuality }}</span></h4>
							<h4 class="price">Prix : <span>@if($event->price == 0) {{ "Gratuit" }} @else {{ $event->price.'€' }} @endif</span></h4>
							<p class="product-description">
								{{ $event->content }}
							</p>
							@if( Session::get('connect') != null && $event->past == 0)
							<div class="action">
								<button class="add-to-cart btn btn-outline-secondary" type="button">Participer</button>
							</div>
							@endif
							@if(Session::get('connect') == 2)
							<a  onclick= "location.href='/sendMailEventImg/{{$event->IDevent}}'" class="btn btn-outline-warning"><i class="fas lamation"></i> Signaler</a>
							@endif
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	@if($event->past == 1 )
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Photos de l'évènement
				</div>
				<div class="card-body">
					<ul class="list-group list-group-flush">
						<li class="list-group-item">
							<div id="carousel" class="carousel slide carousel-fade" data-ride="carousel" data-interval="6000">
								<ol class="carousel-indicators">
									<li data-target="#carousel" data-slide-to="0"></li>
									@foreach($images as $image)
									<?php $i = 1; ?>
									<li data-target="#carousel" data-slide-to="{{ $i }}"></li>
									@php
									$i++;
									@endphp
									@endforeach
								</ol>
								<div class="carousel-inner" role="listbox">
									<div class="carousel-item active">
										<img src="/storage/{{$event->thumbnail}}" alt="responsive image" class="d-block img-fluid">
										<div class="carousel-caption">
											<div>
												<p>Photo de base</p>
											</div>
										</div>
									</a>
								</div>
								@foreach($images as $image)
								<div class="carousel-item ">
									<a href="image/{{ $image->IDimg }}">
										<img src="/storage/{{$image->content}}" alt="responsive image" class="d-block img-fluid">
										<div class="carousel-caption">
											<div>
												<a href="image/{{ $image->IDimg }}" class="btn btn-outline-secondary">Voir</a>
											</div>
										</div>
									</a>
								</div>
								@endforeach
							</div>
							<a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
								<span class="carousel-control-prev-icon" aria-hidden="true"></span>
								<span class="sr-only">Previous</span>
							</a>
							<a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
								<span class="carousel-control-next-icon" aria-hidden="true"></span>
								<span class="sr-only">Next</span>
							</a>
						</div>
					</li>
					@if($event->attendee)
					<li class="list-group-item">
						
							<form method="post" action="/event/addimg/{{$event->IDevent}}" enctype="multipart/form-data">
                       	     {{ csrf_field() }}
                       	     <label class="label">Ajouter une photo à l'évènement</label>
                       	     <div class="control">
                       	         <input type="file" name="eventImg" class="form-control-file marginbot">
                       	     </div>
                       	     <button type="submit" class="btn btn-secondary">Valider</button>
                       	     @if ($errors->has('eventImg'))
                       	     	<p class="help is-danger">{{$errors->first('eventImg')}}</p>
                      	     @endif
                      	  </form>
                        @endif	
					</li>
				</ul>
			</div>
		</div>
	</div>
</div>
@endif
@if( Session::get('connect') != null)
<div class="row margintop">
	<div class="col-md-10 offset-md-1">
		<div class="card">
			<div class="card-header">
				Poster un commentaire
			</div>
			<div class="card-body">
				<form id="formcom">
					@csrf
					<div class="form-group">
						<div class="form-group">
							<label for="exampleFormControlTextarea1">Votre commentaire :</label>
							<textarea class="form-control" id="newcomment" rows="3"></textarea>
						</div>
						<div class="d-flex justify-content-center">
							<button type="submit" class="btn btn-outline-secondary">Envoyer</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
@endif
<div class="row margintop">
	<div class="col-md-10 offset-md-1">
		<div class="card">
			<div class="card-header">
			</div>
			<div class="card-body">
				<ul class="list-group list-group-flush">
					@if(!empty($comments[0]))
					@foreach($comments as $comment)
					<?php
						$sep = explode(" ", $comment->ts);
						$time = $sep[1];
						$date = explode("-", $sep[0]);
						$date = $date[2]."/".$date[1]."/".$date[0];
					?>
					<li class="list-group-item">
						<div class="card noborder">
							<div class="card-body">
								<h5 class="card-title marginbot">{{$comment->userfirstname}} {{$comment->username}} - {{$comment->usercenter}}</h5>
								<h6 class="card-subtitle marginbot">{{$date}} {{$time}}</h6>
								<p class="card-text">{{$comment->content}}</p>
							</div>
						</div>
					</li>
					@if(Session::get('connect') == 2)
					<a  onclick= "location.href='/sendMailComment/{{$event->IDevent}}'" class="btn btn-outline-warning"><i class="fas lamation"></i> Signaler</a>
					@endif
					@endforeach
					@else
					<li class="list-group-item">
						<div class="card noborder">
							<div class="card-body">
								<p class="card-text">Pas de commentaire à afficher</p>
							</div>
						</div>
					</li>
					@endif
				</ul>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(()=>{
			$('#formcom').submit((event)=>{
				event.preventDefault();
				$.ajax({
					type: 'POST',
					url: 'http://localhost:3000/event/addcomment/'+"{{Session::get('token')}}" ,
					data: {
						"content" : $("#newcomment").val(),
						"IDuser" : {{ Session::get('ID') }},
						"ts": "{{$timepost}}",
						"IDevent" : {{$event->IDevent}},
					},
					dataType: 'json',
					success : (data)=>{
						console.log(data);
					},
					error : (data, status)=>{
						console.log(data);
					}
				});
				location.href = '/event/'+ {{$event->IDevent}};
			});
				});
</script>
</div>
@endsection