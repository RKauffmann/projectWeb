@extends('layouts.app')
@section('content')
<div class="container-fluid">
	<div class="row marginbot">
        <div class="col-md-10 offset-md-1">
            <h2 class="pagetitle">Boîte à idées</h2>
            <hr class="separatortitle">
        </div>
    </div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="card cardArticle">
				<div class="container-fluid">
					<div class="wrapper row">
						<div class="preview col-md-5">
							<div class="preview-pic tab-content">
								<div class="tab-pane active" id="pic-1"><img src="http://placehold.it/400x252" /></div>
							</div>
						</div>
						<div class="details col-md-7">
							<h3 class="product-title">Afterwork #6</h3>
							<p class="product-description">RDV Délirium</p>
							<h4>Date : <span>14/02/19</span></h4>
							<h4 class="price">Prix : <span>Gratuit</span></h4>
							<p class="product-description">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</p>
							<div class="action">
								<button class="add-to-cart btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="Connectez-vous pour participer à cet évènement" type="button">Participer</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection