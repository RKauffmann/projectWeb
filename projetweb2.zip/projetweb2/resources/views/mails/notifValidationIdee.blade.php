Félicitation {{$user->name}} {{$user->first_name}} !
<br>
<p>Ton idée <strong>{{$idea->title}}</strong> a été accepté .</p>