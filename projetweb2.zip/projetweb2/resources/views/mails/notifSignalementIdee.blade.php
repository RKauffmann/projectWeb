{{$user->name}} {{$user->first_name}} a effectué un signalement sur l'élément suivante : <br>
<p>L'idée n°{{$idea->IDidea}} nommé {{$idea->title}}</p>