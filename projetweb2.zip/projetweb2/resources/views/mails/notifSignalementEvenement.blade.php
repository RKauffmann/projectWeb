{{$user->name}} {{$user->first_name}} a effectué un signalement sur l'élément suivante : <br>
	<p>L'événement n°{{$event->IDevent}} contenant : {{$event->name}}</p>