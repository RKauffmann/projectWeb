{{$user->name}} {{$user->first_name}} a effectué la commande suivante : <br>
<table class="table table-striped">
	<thead>
		<tr>
			<th scope="col">Article</th>
			<th scope="col">Disponibilité</th>
			<th scope="col" class="text-center">Quantité</th>
			<th scope="col" class="text-right">Prix unitaire</th>
		</tr>
	</thead>
	<tbody>
		@foreach($orders as $order)
			<tr>
				<td>{{$order->title}}</td>
				@if($order->quantityStock >= $order->quantity) 
					<td>En stock</td>
				@else
					<td>Rupture de stock</td>
				@endif
				<td class="text-center">{{$order->quantity}}</td>
				<td class="text-right">{{$order->price}} €</td>
			</tr>
		@endforeach
		<tr>
			<td><strong>Total</strong></td>
			<td class="text-right"><strong>{{$totalPrice}} €</strong></td>
		</tr>
	</tbody>
</table>