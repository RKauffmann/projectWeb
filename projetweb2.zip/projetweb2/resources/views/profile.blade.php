@extends('layouts.app')
@section('content')
<div class="container">
	<div class="row my-2">
		<div class="col-lg-8 order-lg-2">
			<ul class="nav nav-tabs">
				<li class="nav-item">
					<a href="" data-target="#profile" data-toggle="tab" class="nav-link active"><i class="fas fa-id-card"></i> Profil</a>
				</li>
				<li class="nav-item">
					<a href="" data-target="#activity" data-toggle="tab" class="nav-link"><i class="fas fa-chart-line"></i> Activité</a>
				</li>
				<li class="nav-item">
					<a href="" data-target="#images" data-toggle="tab" class="nav-link"><i class="fas fa-chart-line"></i> Images</a>
				</li>
			</ul>
			<div class="tab-content py-4">
				<div class="tab-pane active" id="profile">
					<h5 class="mb-3">{{$profile->first_name}} {{$profile->name}}</h5>
					<div class="row">
						<div class="col-md-12">
							<p>
								Rôle : {{$profile->status}}
							</p>
							<p>
								Adresse mail : {{$profile->email}}
							</p>
							<p>
								Centre : {{$profile->center}}
							</p>
						</div>
					</div>
				</div>
				<div class="tab-pane" id="activity">
					<div class="row">
						<div class="col-md-12">
							<h4 class="m-y-2"> idées</h4>
							<div class="alert alert-info alert-dismissable">
								<a class="panel-close close" data-dismiss="alert">×</a>
								Voici les idées que vous avez proposé
							</div>
							@foreach($ideas as $idea)
							{{$idea->title}}<br>
							{{$idea->content}}<br><br>
							@endforeach
							<h4 class="m-y-2">Evènements </h4>
							<div class="alert alert-info alert-dismissable">
								<a class="panel-close close" data-dismiss="alert">×</a>
								Voici les évènements auxquels vous participez
							</div>
							@foreach($events as $event)
							<?php
								$date = explode("-", $event->date);
								$date = $date[2]."/".$date[1]."/".$date[0];
							?>
							{{$event->name}}, le {{$date}}	<br>
							@endforeach
						</div>
					</div>
				</div>
				<div class="tab-pane" id="images">
					<form method="post" action="/dlallimg">
						@csrf
						<button type="submit" name="dlallimg"> télécharger toutes les images</button>
					</form>
					
				</div>
			</div>
		</div>
		<div class="col-lg-4 order-lg-1 text-center">
			<img src="/storage/{{$profile->imgUser}}" class="mx-auto img-fluid img-circle d-block" alt="avatar">
			<form method="post" action="/avatar-modification" enctype="multipart/form-data">
				{{ csrf_field() }}
				<div class="field">
					<label class="label">Photo de profil</label>
					<div class="control">
						<input type="file" name="avatar" class="form-control-file marginbot">
					</div>
					@if ($errors->has('avatar'))
					<p class="help is-danger">{{$errors->first('avatar')}}</p>
					@endif
				</div>
				<div class="field">
					<div class="control">
						<button class="btn btn-secondary" type="submit">Modifier ma photo de profil</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
@endsection