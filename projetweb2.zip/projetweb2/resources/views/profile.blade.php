@extends('layouts.app')
@section('content')
<div class="container">
	<div class="row my-2">
		<div class="col-lg-8 order-lg-2">
			<ul class="nav nav-tabs">
				<li class="nav-item">
					<a href="" data-target="#profile" data-toggle="tab" class="nav-link active"><i class="fas fa-id-card"></i> Profil</a>
				</li>
				<li class="nav-item">
					<a href="" data-target="#activity" data-toggle="tab" class="nav-link"><i class="fas fa-chart-line"></i> Activité</a>
				</li>
			</ul>
			<div class="tab-content py-4">
				<div class="tab-pane active" id="profile">
					<h5 class="mb-3">{{$profile->first_name}} {{$profile->name}}</h5>
					<div class="row">
						<div class="col-md-12">
							<p>
								Rôle : {{$profile->status}}
							</p>
							<p>
								Adresse mail : {{$profile->email}}
							</p>
							<p>
								Centre : {{$profile->center}}
							</p>
						</div>
					</div>
				</div>
				<div class="tab-pane" id="activity">
					<div class="row">
						<div class="col-md-12">
							<h4 class="m-y-2">Evènements et idées</h4>
							<div class="alert alert-info alert-dismissable">
								<a class="panel-close close" data-dismiss="alert">×</a>
								Voici les idées que vous avez proposé et les évènements auxquels vous participez
							</div>
							<table class="table table-hover table-striped">
								<tbody>
									<tr>
										<td>
											<span class="pull-xs-right font-weight-bold">3 hrs ago</span> Here is your a link to the latest summary report from the..
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-4 order-lg-1 text-center">
			<img src="//placehold.it/150" class="mx-auto img-fluid img-circle d-block" alt="avatar">
			<label class="custom-file">
				<input type="file" id="file" class="custom-file-input">
				<span class="custom-file-control">Choisir un fichier</span>
			</label>
		</div>
	</div>
</div>
@endsection