@php
   if(Session::get('connect') !=3){
    header('Location: /');
    exit();
}
@endphp
@extends('layouts.admin')
@section('content')


<div class="container-fluid">
    <div class="row marginbot">
        <div class="col-md-10 offset-md-1">
            <h2 class="pagetitle">Page d'administration</h2>
            <hr class="separatortitle">
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-10 order-md-2">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a href="" data-target="#profile" data-toggle="tab" class="nav-link active"><i class="fas fa-users"></i> Utilisateurs</a>
                </li>
                <li class="nav-item">
                    <a href="" data-target="#activity" data-toggle="tab" class="nav-link"><i class="fas fa-calendar-week"></i> Evènements</a>
                </li>
                <li class="nav-item">
                    <a href="" data-target="#settings" data-toggle="tab" class="nav-link"><i class="fas fa-shopping-basket"></i> Boutique</a>
                </li>
            </ul>
            <div class="tab-content py-4">
                <div class="tab-pane active" id="profile">
                    <h5 class="mb-3"></h5>
                    <div class="row">
                        <div class="col-md-12">
                            <body>
                                <table id="usertab" class="display" style="width: 100%">
                                    <thead>
                                        <tr><th>Nom</th><th>Prénom</th><th>Centre</th><th>Rôle</th><th>Adresse mail</th></tr>
                                    </thead>
                                    <tbody>
                                        @foreach($profiles as $profile)
                                        <tr><td>{{$profile->name}}</td><td>{{$profile->first_name}}</td><td>{{$profile->center}}</td><td>{{$profile->status}}</td><td>{{$profile->email}}</td></tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </body>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="activity">
                    <div class="row">
                        <div class="col-md-12">
                            <body>
                                <table id="eventtab" class="display" style="width: 100%">
                                    <thead>
                                        <tr><th>Nom</th><th>Description courte</th><th>Date</th><th>Prix</th><th>Statut</th><th>Proposé par</th></tr>
                                    </thead>
                                    <tbody>
                                        @foreach($events as $event)
                                        <tr><td>{{$event->name}}</td><td>{{$event->description}}</td><td>{{$event->date}}</td><td>{{$event->price}}</td><td>{{$event->past}}</td><td>{{$event->IDuser}}</td></tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </body>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection