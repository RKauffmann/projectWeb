@extends('layouts.app')
@section('content')
<meta name="csrf-token" content="{{ csrf_token() }}">
<div class="container-fluid">
	<div class="row marginbot">
		<div class="col-md-10 offset-md-1">
			<h2 class="pagetitle">Boîte à idées</h2>
			<hr class="separatortitle">
		</div>
	</div>
	

	@if( Session::get('connect') != null)
	<div class="row margintop">
		<div class="col-md-10 offset-md-1">
			<div class="alert alert-secondary text-center" role="alert">
				Pour proposer une idée, merci d'utiliser <a href="#formevent" class="alert-link">ce formulaire</a>. Votre proposition sera étudiée par les membres du BDE et une réponse vous sera envoyée sur votre adresse mail.
				</button>
			</div>
		</div>
	</div>
	@endif
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-2 margintop">
						<div class="card">
							<div class="card-header">
								Filtrer
							</div>
							<div class="card-body">
								<form method="POST" action="{{ route('filtreIdea') }}">
									{{csrf_field()}}
									<div class="form-group">
										<div class="pull-right">
											@foreach($tags as $tag)
											<div class="form-check">
												<input class="form-check-input" type="radio" value="{{$tag->IDtag}}" id="filtre{{$tag->IDtag}}" name="filtre" checked="checked">
												<label class="form-check-label" for="filtre{{$tag->IDtag}}">
													{{$tag->name}}
												</label>
											</div>
											@endforeach
										</div>
									</div>
									<div class="form-row">
										<button type="submit" class="btn btn-secondary">
										Filtrer
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-md-10">
						<div class="container-fluid margintop">
							<div class="row" id="refreshdiv">
								@foreach ($ideas as $key => $idea) 
								<div class="col-sm-6">
									<div class="card">
										<div class="container-fluid">
											<div class="row">
												<div class="col-md-6">
													<div class="card-body">
														<h5 class="card-title">{{$idea->title}}</h5>
														<p class="card-text">{{$idea->content}}</p>
													</div>
												</div>
											</div>
										</div>
										<div class="card-footer text-muted">
												@if($idea->liked == 1)
											<a  id="like{{$idea->IDidea}}" href="javascript:like({{$idea->IDidea}},{{$idea->liked}})" class="btn btn-outline-primary">
											@else
											<a  id="like{{$idea->IDidea}}" href="javascript:like({{$idea->IDidea}},{{$idea->liked}})" class="btn btn-outline-secondary">
											@endif
												<i class="fas fa-thumbs-up"></i>  <span  class="likes">{{$idea->nblike}}</span></a>
											

													

											@if($idea->liked != 1)
											<a id="dislike{{$idea->IDidea}}" href="javascript:dislike({{$idea->IDidea}},{{$idea->liked}})" class="btn btn-outline-secondary">
											@else 
											<a id="dislike{{$idea->IDidea}}" href="javascript:dislike({{$idea->IDidea}},{{$idea->liked}})" class="btn btn-outline-danger">
											@endif
											<i class="fas fa-thumbs-down"></i>  <span class="dislikes">{{$idea->nbdislike}}</span></a>


											 @if( Session::get('connect') == 3)
											<div class="float-right">
												<a  onclick="Valider({{$idea->IDidea}})"class="btn btn-outline-secondary">Valider</a>
											</div>
											@endif
										</div>
									</div>
								</div>
								@endforeach
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	 @if( Session::get('connect') != null)
	<div class="row margintop" id="formevent">
		<div class="col-md-10 offset-md-1">
			<div class="card">
				<div class="card-header">
					Formulaire de proposition
				</div>
				<div class="card-body">
					<form id="formaddidea">
						@csrf
						<div class="form-group row">
							<label for="ideaname" class="col-md-2 col-form-label">Titre de l'idée</label>
							<div class="col-md-10">
								<input type="text" class="form-control" maxlength="25" name="ideaname" id="ideaname" placeholder="25 caractères max.">
							</div>
						</div>
						<div class="form-group row">
							<label for="ideadesc" class="col-md-2 col-form-label">Description de l'idée</label>
							<div class="col-md-10">
								<textarea class="form-control" rows="5" maxlength="280" name="ideadesc" id="ideadesc" placeholder="280 caractères max."></textarea>
							</div>
						</div>
						<div class="text-center">
							<button type="submit" href="{{ route('idea') }}" class="btn btn-secondary" id="btnaddidea">Proposer cette idée</button>
						</div >
					</form>
				</div>
			</div>
		</div>
	</div>
	@endif
	 <script>	 
	 	$(document).ready(()=>{
	 		$('#formaddidea').submit((event)=>{
	 			event.preventDefault();
	 			$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/idea',
	 				data: {
	 					"title" : $("#ideaname").val(),
	 					"content" : $("#ideadesc").val(),
	 					"IDuser" : {{ Session::get('ID') }},
	 					"ts": "{{$time}}"
	 				},
	 				dataType: 'json',
	 				error : (data, status)=>{
	 					console.log(data);
	 				}
	 			});
	 		});
	 	});

</script> 
<script >
 function like(IDidea,liked){
 	if({{ Session::get('connect') }} != null){
		if(liked != 1){
				if(liked === 0 ){

		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteidea/'+IDidea+'/' + {{ Session::get('ID') }},
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
				}	
	 		$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/idea/like',
	 				data: {
	 					"IDidea" : IDidea,
	 					"IDuser" : {{ Session::get('ID') }},
	 				},
	 				dataType: 'json',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}	
			 });
 	}else{
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteidea/'+IDidea+'/' + {{ Session::get('ID') }},
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
 	}	
 	}
 	$('#refreshdiv').load('refreshidea');
}   

</script>	
<script >
	function dislike(IDidea,liked){
		if({{Session::get('connect')}} !=  null){
		if(liked != 0){
				if(liked === 1 ){
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteidea/'+IDidea+'/' +{{ Session::get('ID') }},
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
			 	
				}
	 		$.ajax({
	 				type: 'POST',
	 				url: 'http://localhost:3000/idea/dislike',
	 				data: {
	 					"IDidea" : IDidea,
	 					"IDuser" : {{ Session::get('ID') }},
	 				},
	 				dataType: 'json',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}	
			 });
		 }else{
		 				$.ajax({
		 					headers: {
   						     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   							 },
	 						type: 'DELETE',
	 						url: 'http://localhost:3000/deleteidea/'+IDidea+'/' + {{ Session::get('ID') }},
	 						async : false,
	 					    success: function(result) {
        						console.log(result);
   							},
   							error: (data)=>{
   								console.log(data);
   							}
			 			});
 	}
		}
		$('#refreshdiv').load('refreshidea');
}
</script>
<script >
	function Valider(IDidea){
	 		$.ajax({
	 				type: 'DELETE',
	 				url: 'http://localhost:3000/valididea/' + IDidea + '/',
	 				success : (data)=>{
	 					console.log(data);
	 				},
	 				error : (data, status)=>{
	 					console.log(data);
	 				}	
			 });
	 		$('#refreshdiv').load('refreshidea');
		 }
</script>
</div>
@endsection