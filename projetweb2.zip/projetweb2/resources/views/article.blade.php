@extends('layouts.app')
@section('content')

<div class="container-fluid">
	<div class="row marginbot">
        <div class="col-md-10 offset-md-1">
            <h2 class="pagetitle">Boutique</h2>
            <hr class="separatortitle">
        </div>
    </div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="card cardArticle">
				<div class="container-fluid">
					<div class="wrapper row">
						<div class="preview col-md-5">
							<div class="preview-pic tab-content">
								<div class="tab-pane active" id="pic-1"><img src="http://placehold.it/400x252" /></div>
							</div>
						</div>
						<div class="details col-md-7">
							<h3 class="product-title">{{$article->title}}</h3>
							<p class="product-description">{{$article->description}}</p>
							<h4 class="price">Prix : <span>{{$article->price}}€</span></h4>
							@if(Session::get('connect') != null)
							<div class="action">
								<button onclick="location.href='/addPanier/{{$article->IDarticle}}'"  class="add-to-cart btn btn-outline-secondary" data-toggle="tooltip" data-placement="bottom" title="Connectez-vous pour ajouter cet article à votre panier" type="button"><i class="fas fa-shopping-cart"></i> Ajouter au panier</button>
							</div>
							@endif
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection