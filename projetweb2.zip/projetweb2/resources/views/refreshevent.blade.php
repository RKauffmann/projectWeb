<?php

    	$events = DB::connection('bddbde')->table('events')->orderBy('past','ASC')->orderBy('date','ASC')->get();
    	$topEvents = DB::connection('bddbde')->table('events')->where('past','0')->orderBy('date','ASC')->take('3')->get();
    	$tags = DB::connection('bddbde')->table('tag')->where('articleTag','0')->get();
        foreach ($events as $key => $event) {
            $temp = DB::connection('bddbde')->select('CALL nbvoteeventlike('.$event->IDevent.')');
            $event->nblike = $temp[0]->sortie;
            $temp = DB::connection('bddbde')->select('CALL nbvoteeventdislike('.$event->IDevent.')');
            $event->nbdislike = $temp[0]->sortie;

            $event->liked =  DB::connection('bddbde')->table('_voteevent')->Where('IDuser',Session::get('ID'))->Where('IDevent',$event->IDevent)->value('reaction');
        }
?>
@foreach($events as $event)
								<?php
									$date = explode("-", $event->date);
									$showdate = $date[2]."/".$date[1]."/".$date[0];
									$date = $date[2]."-".$date[1]."-".$date[0];
								?>
								<div class="col-md-6 margintop">
									<div class="card">
										<div class="container-fluid">
											<div class="row">
												<div class="col-md-6">
													<div class="card-body">
														<h5 class="card-title"><a href="event/{{ $event->IDevent }}">{{ $event->name }}</a></h5>
														<h6 class="card-subtitle mb-2 text-muted">{{ $event->punctuality }} -  @if($event->price == 0) {{ "Gratuit" }} @else {{ $event->price.'€' }} @endif</h6>
														<p class="card-text">{{ $event->description }}</p>
													</div>
												</div>
												<div class="col-md-6 margintop marginbot d-flex justify-content-center">
													<a href="event/{{ $event->IDevent }}"><img srcset="http://placehold.it/100" alt="responsive image" class="d-block img-fluid"></a>
												</div>
											</div>
										</div>
										<div class="card-footer text-muted">
											{{ $showdate }}
											@if ($event->past == 1)
											<?php echo('<span class="badge badge-danger">Passé</span>') ?>
											@elseif ($date == date('d-m-Y'))
											<?php echo('<span class="badge badge-warning">Aujourd\'hui</span>') ?>
											@else
											<?php echo('<span class="badge badge-success">Bientôt</span>') ?>
											@endif
											@if( Session::get('connect') != null )
											<div class="float-right">
											@if($event->liked == 1)
											<a  id="like{{$event->IDevent}}" href="javascript:like({{$event->IDevent}},{{$event->liked}})" class="btn btn-outline-primary">
											@else($event->liked ==0)
											<a  id="like{{$event->IDevent}}" href="javascript:like({{$event->IDevent}},{{$event->liked}})" class="btn btn-outline-secondary">
											@endif
												<i class="fas fa-thumbs-up"></i>  <span  class="likes">{{$event->nblike}}</span></a>
											
											@if($event->liked == 0)
											<a id="dislike{{$event->IDevent}}" href="javascript:dislike({{$event->IDevent}},{{$event->liked}})" class="btn btn-outline-danger">
											@else 
											<a id="dislike{{$event->IDevent}}" href="javascript:dislike({{$event->IDevent}},{{$event->liked}})" class="btn btn-outline-secondary">
											@endif
											<i class="fas fa-thumbs-down"></i>  <span class="dislikes">{{$event->nbdislike}}</span></a>
												<a href="#" class="btn btn-outline-secondary" onclick="participer({{$event->IDevent}})">Participer</a>
											</div>
											@endif
										</div>
									</div>
								</div>
								@endforeach