@extends('layouts.app')
@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div id="carousel" class="carousel slide carousel-fade" data-ride="carousel" data-interval="6000">
				<ol class="carousel-indicators">
					<li data-target="#carousel" data-slide-to="0" class="active"></li>
					<li data-target="#carousel" data-slide-to="1"></li>
					<li data-target="#carousel" data-slide-to="2"></li>
				</ol>
				<div class="carousel-inner" role="listbox">
					<div class="carousel-item active">
						<a href="#">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							<div class="carousel-caption">
								<div>
									<h2>Test</h2>
									<p>Lorem ipsum dolor sit amet.</p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
					<div class="carousel-item">
						<a href="#">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							<div class="carousel-caption justify-content-center align-items-center">
								<div>
									<h2>Test</h2>
									<p>Lorem ipsum dolor sit amet.</p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
					<div class="carousel-item">
						<a href="#">
							<img srcset="http://placehold.it/1250x200" alt="responsive image" class="d-block img-fluid">
							
							<div class="carousel-caption justify-content-center align-items-center">
								<div>
									<h2>Test</h2>
									<p>Lorem ipsum dolor sit amet.</p>
									<span class="btn btn-sm btn-outline-secondary">Voir</span>
								</div>
							</div>
						</a>
					</div>
					<!-- /.carousel-item -->
				</div>
				<!-- /.carousel-inner -->
				<a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-2 margintop">
						<div class="card">
							<div class="card-header">
								Filtrer
							</div>
							<div class="card-body">
								<form>
									<div class="form-group">
										<div class="form-check">
											<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
											<label class="form-check-label" for="defaultCheck1">
												Validées
											</label>
										</div>
										<div class="form-check">
											<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
											<label class="form-check-label" for="defaultCheck1">
												Refusées
											</label>
										</div>
										<div class="form-check">
											<input class="form-check-input" type="checkbox" value="" id="defaultCheck2">
											<label class="form-check-label" for="defaultCheck2">
												A valider
											</label>
										</div>
									</div>
									<div class="form-row">
										<button type="submit" class="btn btn-secondary">
										Filtrer
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-md-10">
						<div class="container-fluid margintop">
							<div class="row">
								<div class="col-sm-6">
									<div class="card">
										<div class="card-body">
											<h5 class="card-title">Afterwork #6</h5>
											<h6 class="card-subtitle mb-2 text-muted">Hebdomadaire - Gratuit</h6>
											<p class="card-text">RDV Delirium</p>
										</div>
										<div class="card-footer text-muted">
											Il y a 2 jours
											<div class="float-right">
												<a href="#" class="btn btn-outline-secondary">Valider</a>
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="card">
										<div class="card-body">
											<h5 class="card-title">Afterwork #6</h5>
											<h6 class="card-subtitle mb-2 text-muted">Hebdomadaire - Gratuit</h6>
											<p class="card-text">RDV Delirium</p>
										</div>
										<div class="card-footer text-muted">
											Il y a 2 jours
											<div class="float-right">
												<a href="#" class="btn btn-outline-secondary">Valider</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection