<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row my-2">
		<div class="col-lg-8 order-lg-2">
			<ul class="nav nav-tabs">
				<li class="nav-item">
					<a href="" data-target="#profile" data-toggle="tab" class="nav-link active"><i class="fas fa-id-card"></i> Profil</a>
				</li>
				<li class="nav-item">
					<a href="" data-target="#cart" data-toggle="tab" class="nav-link"><i class="fas fa-shopping-cart"></i> Panier</a>
				</li>
				<li class="nav-item">
					<a href="" data-target="#messages" data-toggle="tab" class="nav-link"><i class="far fa-envelope"></i> Messages</a>
				</li>
				<li class="nav-item">
					<a href="" data-target="#ideas" data-toggle="tab" class="nav-link"><i class="far fa-lightbulb"></i> Idées</a>
				</li>
			</ul>
			<div class="tab-content py-4">
				<div class="tab-pane active" id="profile">
					<h5 class="mb-3">Romain Kauffmann</h5>
					<div class="row">
						<div class="col-md-6">
							<h6>A propos</h6>
							<p>
								Vice-président BDE à ses heures perdues
							</p>
						</div>
						<div class="col-md-6">
							<h6>Badges récents</h6>
							<a href="#" class="badge badge-light badge-pill"><i class="fas fa-beer"></i></a>
						</div>
						<div class="col-md-12">
							<h5 class="mt-2"><span class="fa fa-clock-o ion-clock float-right"></span> Activité récente</h5>
							<table class="table table-sm table-hover table-striped">
								<tbody>
									<tr>
										<td>
											<strong>Romain Kauffman</strong> a proposé un évènement : <strong>`Afterwork #245 2019`</strong>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
					<!--/row-->
				</div>
				<div class="tab-pane" id="messages">
					<div class="alert alert-danger alert-dismissable">
						<a class="panel-close close" data-dismiss="alert">×</a> Ceci est une <strong>alerte</strong>.
					</div>
					<table class="table table-hover table-striped">
						<tbody>
							<tr>
								<td>
									<span class="float-right font-weight-bold">Il y a 3h</span> Kauffmann vous a encore invité à boire
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="tab-pane" id="ideas">
					<div class="alert alert-danger alert-dismissable">
						<a class="panel-close close" data-dismiss="alert">×</a> Ceci est une <strong>alerte</strong>.
					</div>
					<table class="table table-hover table-striped">
						<tbody>
							<tr>
								<td>
									<span class="float-right font-weight-bold">Il y a 3h</span> Kauffmann vous a encore invité à boire
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="tab-pane" id="cart">
					<div class="alert alert-danger alert-dismissable">
						<a class="panel-close close" data-dismiss="alert">×</a> Ceci est une <strong>alerte</strong>.
					</div>
					<table class="table table-hover table-striped">
						<tbody>
							<tr>
								<td>
									<span class="float-right font-weight-bold">Il y a 3h</span> Kauffmann vous a encore invité à boire
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="col-lg-4 order-lg-1 text-center">
			<img src="//placehold.it/150" class="mx-auto img-fluid img-circle d-block" alt="avatar">
			<label class="custom-file">
				<input type="file" id="file" class="custom-file-input">
				<span class="custom-file-control">Choisir un fichier</span>
			</label>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>