<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <form name="register" method="POST" onsubmit="return validateFrom()" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>
                    <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="firstname"><?php echo e(__('prenom')); ?></label>
                        <input id="firstname" type="text" class="form-control<?php echo e($errors->has('firstname') ? ' is-invalid' : ''); ?>" name="firstname" value="<?php echo e(old('firstname')); ?>" required autofocus>
                        <?php if($errors->has('firstname')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('firstname')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="name"><?php echo e(__('nom')); ?></label>
                        <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>"  required autofocus>
                        <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-row">
                    <label for="email"><?php echo e(__('Adresse e-mail')); ?></label>
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                    <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-row">
                    <label for="center"><?php echo e(__('Centre')); ?></label>
                    <input id="center" type="center" class="form-control<?php echo e($errors->has('center') ? ' is-invalid' : ''); ?>" name="center" required>
                    <?php if($errors->has('center')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('center')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-row">
                    <label for="password"><?php echo e(__('Mot de passe')); ?></label>
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                    <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-row">
                    <label for="password-confirm"><?php echo e(__('Confirmer le mot de passe')); ?></label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                </div>
                <div class="form-row">
                    <button type="submit" class="btn btn-secondary margintop">
                    <?php echo e(__('Créer le compte')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript" name="validate">
    
function validateFrom(){
    var x = document.forms['register']['firstname'].value;
    console.log(document.forms['register']['firstname'].value);
    if(x == ""){
        alert ("Name must be filled out");
    }
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>