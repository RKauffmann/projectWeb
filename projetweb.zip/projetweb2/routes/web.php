<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::get('register', function(){
	return view('auth/register');
});

Route::get('login',function(){
	return view('auth/login');
})->name('login');

Route::get('idea',function(){
	return view('ideabox');
})->name('idea');

Route::get('events',function(){
	return view('events');
})->name('events');

Route::get('profile',function(){
	return view('profile');
})->name('profile');

Route::get('shop',function(){
	return view('shop');
})->name('shop');

Route::get('admin',function(){
	return view('admin');
})->name('admin');

Route::get('logout','Auth\logoutController@logout')->name('logout');

Route::post('register', 'Auth\RegisterController@createaccount')->name('register');

Route::post('login', 'Auth\LoginController@login')->name('login');
