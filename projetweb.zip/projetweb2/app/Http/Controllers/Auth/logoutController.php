<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class logoutController extends Controller
{
    public function logout(){
    	session_unset();
    	return view('welcome');
	}
}