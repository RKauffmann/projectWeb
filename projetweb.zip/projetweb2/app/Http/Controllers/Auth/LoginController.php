<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function login(Request $request){

     
     $url = 'http://localhost:3000/'. $request->input('email').'/';
     $opts=array(
    "http"=>array(
        'method'=>"GET"
    ),
); 
     $response = file_get_contents($url,false,stream_context_create($opts));
        
        $tabresp = explode('"', $response);
     
        
                  if(Hash::check($request->input('password'),$tabresp[21]))
                       {
                                $str = $tabresp[2];
                              
                             $str = rtrim($str,",");
                             $str = ltrim($str,":");
                              $Statment = DB::connection('bddbde')->table('users')->Where('IDuser',1)->first();
                              $_SESSION['ID'] = $str;
                              $_SESSION['connect'] = $Statment->IDstatus;
                            echo $_SESSION['connect'];
                               return view('welcome');
                       }
        
                
         }
}
